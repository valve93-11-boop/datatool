import os
import sys
import subprocess
import json
import shutil
import unicodedata
from pathlib import Path

BASE_DIR = Path(__file__).parent
VENV_DIR = BASE_DIR / ".venv"
REQUIREMENTS = BASE_DIR / "requirements.txt"

def ensure_venv():
    if sys.prefix == str(VENV_DIR):
        return

    if os.name == "nt":
        python_exe = VENV_DIR / "Scripts" / "python.exe"
    else:
        python_exe = VENV_DIR / "bin" / "python"

    if not VENV_DIR.exists():
        subprocess.check_call([sys.executable, "-m", "venv", str(VENV_DIR)])
        subprocess.check_call([str(python_exe), "-m", "pip", "install", "--upgrade", "pip"])
        subprocess.check_call([str(python_exe), "-m", "pip", "install", "-r", str(REQUIREMENTS)])

    subprocess.Popen([str(python_exe), str(BASE_DIR / "main.py")])
    sys.exit()

ensure_venv()

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QApplication,
    QFileDialog,
    QGridLayout,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QSizePolicy,
    QSpacerItem,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)

from ui_style import THEME, CardFrame, NavButton, logo_widget

MODULE_DIR = BASE_DIR / "module"
CONFIG_PATH = BASE_DIR / "config.json"

def normalize_name(name: str) -> str:
    name = unicodedata.normalize("NFKD", name).encode("ascii", "ignore").decode()
    name = name.lower()
    name = "".join(c if c.isalnum() else "_" for c in name)
    name = "_".join(filter(None, name.split("_")))
    return name or "module"

class TileButton(QPushButton):
    def __init__(self, text: str):
        super().__init__(text)
        self.setCursor(Qt.PointingHandCursor)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        f = self.font()
        f.setPointSize(11)
        f.setWeight(QFont.DemiBold)
        self.setFont(f)
        self.setStyleSheet(
            '''
            QPushButton{
                background: rgba(255,255,255,255);
                border: 1px solid rgba(230,233,238,255);
                border-radius: 16px;
                padding: 14px;
                color: rgba(28,31,35,255);
            }
            QPushButton:hover{ background: rgba(243,246,252,255); }
            QPushButton:pressed{ background: rgba(235,240,250,255); }
            '''
        )

class PrimaryButton(QPushButton):
    def __init__(self, text: str):
        super().__init__(text)
        self.setCursor(Qt.PointingHandCursor)
        self.setFixedHeight(34)
        f = self.font()
        f.setPointSize(10)
        f.setWeight(QFont.DemiBold)
        self.setFont(f)
        self.setStyleSheet(
            '''
            QPushButton{
                background: rgba(76,122,255,255);
                border: 1px solid rgba(76,122,255,255);
                border-radius: 12px;
                padding: 0 14px;
                color: rgba(255,255,255,255);
            }
            QPushButton:hover{ background: rgba(64,110,245,255); }
            QPushButton:pressed{ background: rgba(54,98,235,255); }
            QPushButton:disabled{
                background: rgba(190,200,220,255);
                border: 1px solid rgba(190,200,220,255);
                color: rgba(255,255,255,255);
            }
            '''
        )

class DataTool(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("DataTool")
        self.resize(1200, 760)

        MODULE_DIR.mkdir(exist_ok=True)
        self.config = self._load_config()
        self.modules = []

        self._build_ui()
        self._refresh_modules()

    def _load_config(self):
        if not CONFIG_PATH.exists():
            return {"enabled": {}, "names": {}}
        try:
            return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        except Exception:
            return {"enabled": {}, "names": {}}

    def _save_config(self):
        CONFIG_PATH.write_text(json.dumps(self.config, indent=2, ensure_ascii=False), encoding="utf-8")

    def _build_ui(self):
        root = QWidget()
        root.setStyleSheet(f"background: {THEME['bg'].name()};")
        self.setCentralWidget(root)

        main = QHBoxLayout(root)
        main.setContentsMargins(16, 16, 16, 16)
        main.setSpacing(14)

        self.sidebar = self._build_sidebar()
        main.addWidget(self.sidebar)

        center = QWidget()
        cl = QVBoxLayout(center)
        cl.setContentsMargins(0, 0, 0, 0)
        cl.setSpacing(14)

        topbar = CardFrame()
        tl = QHBoxLayout(topbar)
        tl.setContentsMargins(14, 12, 14, 12)
        tl.setSpacing(10)

        self.page_title = QLabel("Инструменты")
        f = self.page_title.font()
        f.setPointSize(14)
        f.setWeight(QFont.DemiBold)
        self.page_title.setFont(f)
        self.page_title.setStyleSheet("color: rgba(28,31,35,255);")
        tl.addWidget(self.page_title)

        tl.addItem(QSpacerItem(10, 10, QSizePolicy.Expanding, QSizePolicy.Minimum))

        self.btn_add = PrimaryButton("Добавить модуль")
        self.btn_add.clicked.connect(self._add_module)
        tl.addWidget(self.btn_add)

        cl.addWidget(topbar)

        self.stack = QStackedWidget()
        self.tools_page = QWidget()
        self.library_page = QWidget()
        self.stack.addWidget(self.tools_page)
        self.stack.addWidget(self.library_page)
        cl.addWidget(self.stack, 1)

        main.addWidget(center, 1)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if hasattr(self, "stack") and self.stack.currentIndex() == 0:
            self._update_tools_tile_sizes()


    def _build_sidebar(self) -> QWidget:
        w = CardFrame()
        w.setFixedWidth(240)

        lay = QVBoxLayout(w)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        header = QWidget()
        header.setFixedHeight(104)
        hl = QVBoxLayout(header)
        hl.setContentsMargins(18, 14, 16, 8)
        hl.setSpacing(0)

        hl.addWidget(logo_widget(header, "DataTool"), 0, Qt.AlignLeft | Qt.AlignTop)
        hl.addStretch(1)
        lay.addWidget(header)

        content = QWidget()
        cl = QVBoxLayout(content)
        cl.setContentsMargins(16, 12, 16, 16)
        cl.setSpacing(12)

        self.btn_tools = NavButton("Инструменты")
        self.btn_library = NavButton("Библиотека")
        from PySide6.QtWidgets import QButtonGroup
        self.nav_group = QButtonGroup(w)
        self.nav_group.setExclusive(True)
        self.nav_group.addButton(self.btn_tools)
        self.nav_group.addButton(self.btn_library)
        self.btn_tools.setChecked(True)
        self.nav_group.buttonClicked.connect(self._on_nav_clicked)

        cl.addWidget(self.btn_tools)
        cl.addWidget(self.btn_library)
        cl.addItem(QSpacerItem(20, 20, QSizePolicy.Minimum, QSizePolicy.Expanding))

        lay.addWidget(content, 1)
        return w

    def _on_nav_clicked(self, btn):
        if btn is self.btn_tools:
            self._show_tools()
        else:
            self._show_library()

    def _show_tools(self):
        self.page_title.setText("Инструменты")
        self.stack.setCurrentIndex(0)
        self._build_tools_page()

    def _show_library(self):
        self.page_title.setText("Библиотека")
        self.stack.setCurrentIndex(1)
        self._build_library_page()

    def _update_tools_tile_sizes(self):
        enabled = [p for p in self.modules if self.config["enabled"].get(p.name, False)]
        n = len(enabled)
        if n == 0:
            return

        if n <= 3:
            cols = n
        elif n <= 9:
            cols = 3
        else:
            cols = 4

        tile = self._tool_tile_size(cols, n)
        for btn in self.tools_page.findChildren(TileButton):
            btn.setFixedSize(tile, tile)

    def _clear_layout(self, w: QWidget):
        lay = w.layout()
        if lay is None:
            return
        while lay.count():
            it = lay.takeAt(0)
            child_w = it.widget()
            child_l = it.layout()
            if child_w is not None:
                child_w.setParent(None)
                child_w.deleteLater()
            elif child_l is not None:
                self._clear_layout_obj(child_l)

    def _clear_layout_obj(self, lay):
        while lay.count():
            it = lay.takeAt(0)
            child_w = it.widget()
            child_l = it.layout()
            if child_w is not None:
                child_w.setParent(None)
                child_w.deleteLater()
            elif child_l is not None:
                self._clear_layout_obj(child_l)
        lay.deleteLater()

    def _refresh_modules(self):
        self.modules = sorted(MODULE_DIR.glob("*.py"), key=lambda p: p.name.lower())
        for p in self.modules:
            if p.name not in self.config["names"]:
                self.config["names"][p.name] = p.stem
            if p.name not in self.config["enabled"]:
                self.config["enabled"][p.name] = False
        self._save_config()
        self._build_tools_page()
        self._build_library_page()

    def _build_tools_page(self):
        outer = self.tools_page.layout()
        if outer is None:
            outer = QVBoxLayout(self.tools_page)
            outer.setContentsMargins(0, 0, 0, 0)
            outer.setSpacing(0)
        else:
            self._clear_layout(self.tools_page)

        host = QWidget()
        layout = QGridLayout(host)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setHorizontalSpacing(14)
        layout.setVerticalSpacing(14)
        layout.setAlignment(Qt.AlignCenter)
        outer.addWidget(host, 1)

        enabled = [p for p in self.modules if self.config["enabled"].get(p.name, False)]
        n = len(enabled)

        if n == 0:
            card = CardFrame()
            l = QVBoxLayout(card)
            l.setContentsMargins(18, 18, 18, 18)
            t = QLabel("Выберите модули в «Библиотеке» или добавьте новый .py")
            t.setStyleSheet("color: rgba(104,112,124,255);")
            t.setWordWrap(True)
            l.addWidget(t)
            layout.addWidget(card, 0, 0)
            layout.setColumnStretch(0, 1)
            layout.setRowStretch(0, 1)
            return

        if n <= 3:
            cols = n
        elif n <= 9:
            cols = 3
        else:
            cols = 4

        tile = self._tool_tile_size(cols, n)
        for i, p in enumerate(enabled):
            btn = TileButton(self.config["names"].get(p.name, p.stem))
            btn.setFixedSize(tile, tile)
            btn.clicked.connect(lambda _=False, path=p: self._run_module(path))
            r, c = divmod(i, cols)
            layout.addWidget(btn, r, c)

    def _tool_tile_size(self, cols: int, n: int) -> int:
        w = max(0, self.tools_page.width() - 28)
        h = max(0, self.tools_page.height() - 28)
        spacing = 14

        max_w = int((w - spacing * max(cols - 1, 0)) / max(cols, 1))
        rows = (n + cols - 1) // max(cols, 1)
        max_h = int((h - spacing * max(rows - 1, 0)) / max(rows, 1))

        return max(140, min(max_w, max_h, 280))

    def _build_library_page(self):
        outer = self.library_page.layout()
        if outer is None:
            outer = QVBoxLayout(self.library_page)
            outer.setContentsMargins(0, 0, 0, 0)
            outer.setSpacing(0)
        else:
            self._clear_layout(self.library_page)

        host = QWidget()
        layout = QGridLayout(host)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setHorizontalSpacing(14)
        layout.setVerticalSpacing(14)
        layout.setAlignment(Qt.AlignTop)
        outer.addWidget(host, 0)
        outer.addStretch(1)

        cols = 5
        for i, p in enumerate(self.modules):
            card = CardFrame()
            card.setStyleSheet(
                '''
                QFrame#CardFrame{
                    background: rgba(255,255,255,255);
                    border: 1px solid rgba(230,233,238,255);
                    border-radius: 14px;
                }
                '''
            )
            cl = QHBoxLayout(card)
            cl.setContentsMargins(14, 10, 14, 10)
            cl.setSpacing(10)
            card.setFixedHeight(56)

            name = QLabel(self.config["names"].get(p.name, p.stem))
            name.setStyleSheet("color: rgba(28,31,35,255); font-weight: 600;")
            name.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
            cl.addWidget(name, 1)

            enabled = bool(self.config["enabled"].get(p.name, False))

            btn_toggle = QPushButton("Убрать" if enabled else "Добавить")
            btn_toggle.setCursor(Qt.PointingHandCursor)
            btn_toggle.setFixedHeight(30)
            btn_toggle.setStyleSheet(
                '''
                QPushButton{
                    background: rgba(252,253,255,255);
                    border: 1px solid rgba(230,233,238,255);
                    border-radius: 12px;
                    padding: 0 12px;
                    font-weight: 600;
                    color: rgba(28,31,35,255);
                }
                QPushButton:hover{ background: rgba(243,246,252,255); }
                QPushButton:pressed{ background: rgba(235,240,250,255); }
                '''
            )
            btn_toggle.clicked.connect(lambda _=False, path=p, en=enabled: self._set_module_enabled(path, not en))
            cl.addWidget(btn_toggle)

            btn_del = QPushButton("Удалить")
            btn_del.setCursor(Qt.PointingHandCursor)
            btn_del.setFixedHeight(30)
            btn_del.setStyleSheet(
                '''
                QPushButton{
                    background: rgba(252,253,255,255);
                    border: 1px solid rgba(230,233,238,255);
                    border-radius: 12px;
                    padding: 0 12px;
                    font-weight: 600;
                    color: rgba(28,31,35,255);
                }
                QPushButton:hover{ background: rgba(243,246,252,255); }
                QPushButton:pressed{ background: rgba(235,240,250,255); }
                '''
            )
            btn_del.setEnabled(not enabled)
            btn_del.clicked.connect(lambda _=False, path=p: self._delete_module(path))
            cl.addWidget(btn_del)

            r, c = divmod(i, cols)
            layout.addWidget(card, r, c)

        for c in range(cols):
            layout.setColumnStretch(c, 1)

    def _set_module_enabled(self, path: Path, enabled: bool):
        self.config["enabled"][path.name] = bool(enabled)
        self._save_config()
        self._build_tools_page()
        self._build_library_page()

    def _delete_module(self, path: Path):
        if self.config["enabled"].get(path.name, False):
            QMessageBox.warning(self, "Нельзя удалить", "Сначала отключите модуль в библиотеке.")
            return
        if QMessageBox.question(self, "Удалить модуль", f"Удалить «{self.config['names'].get(path.name, path.stem)}»?") != QMessageBox.Yes:
            return
        try:
            path.unlink()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", str(e))
            return
        self.config["enabled"].pop(path.name, None)
        self.config["names"].pop(path.name, None)
        self._save_config()
        self._refresh_modules()

    def _add_module(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Выберите скрипт .py", str(Path.home()), "Python (*.py)")
        if not file_path:
            return

        name, ok = QInputDialog.getText(self, "Имя модуля", "Введите имя для отображения в библиотеке")
        if not ok:
            return
        name = (name or "").strip()
        if not name:
            return

        fname = normalize_name(name) + ".py"
        dest = MODULE_DIR / fname
        if dest.exists():
            QMessageBox.warning(self, "Имя занято", "Модуль с таким именем уже существует.")
            return

        try:
            src = Path(file_path)
            code = src.read_text(encoding="utf-8", errors="ignore")
            compile(code, str(src), "exec")
        except Exception as e:
            QMessageBox.critical(self, "Ошибка файла", f"Скрипт не добавлен.\n\n{e}")
            return

        try:
            shutil.copy(file_path, dest)
        except Exception as e:
            QMessageBox.critical(self, "Ошибка копирования", str(e))
            return

        self.config["names"][fname] = name
        self.config["enabled"][fname] = False
        self._save_config()
        self._refresh_modules()
        self._show_library()

    def _run_module(self, path: Path):
        try:
            subprocess.Popen([sys.executable, str(path)], cwd=str(BASE_DIR))
        except Exception as e:
            QMessageBox.critical(self, "Ошибка запуска", str(e))

if __name__ == "__main__":
    app = QApplication(sys.argv)
    w = DataTool()
    w.show()
    sys.exit(app.exec())
