from __future__ import annotations

from pathlib import Path
from typing import Optional

from PySide6.QtCore import QEasingCurve, Property, QPropertyAnimation, Qt
from PySide6.QtGui import QColor, QFont, QPainter, QPainterPath, QPen, QPixmap
from PySide6.QtWidgets import QApplication, QFrame, QGraphicsDropShadowEffect, QLabel, QPushButton, QSizePolicy, QWidget


def qcolor(r: int, g: int, b: int, a: int = 255) -> QColor:
    return QColor(r, g, b, a)


def blend(c1: QColor, c2: QColor, t: float) -> QColor:
    t = max(0.0, min(1.0, t))
    return QColor(
        int(c1.red() + (c2.red() - c1.red()) * t),
        int(c1.green() + (c2.green() - c1.green()) * t),
        int(c1.blue() + (c2.blue() - c1.blue()) * t),
        int(c1.alpha() + (c2.alpha() - c1.alpha()) * t),
    )


THEME = {
    "bg": qcolor(247, 248, 250),
    "panel2": qcolor(252, 253, 255),
    "border": qcolor(230, 233, 238),
    "text": qcolor(28, 31, 35),
    "muted": qcolor(104, 112, 124),
    "accent": qcolor(76, 122, 255),
    "hover": qcolor(243, 246, 252),
    "press": qcolor(235, 240, 250),
}


def apply_soft_shadow(widget: QWidget, blur: int = 26, y: int = 8, alpha: int = 35) -> None:
    eff = QGraphicsDropShadowEffect(widget)
    eff.setBlurRadius(blur)
    eff.setOffset(0, y)
    eff.setColor(QColor(0, 0, 0, alpha))
    widget.setGraphicsEffect(eff)


class CardFrame(QFrame):
    def __init__(self, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self.setObjectName("CardFrame")
        self.setAttribute(Qt.WA_StyledBackground, True)
        self.setStyleSheet(
            '''
            QFrame#CardFrame{
                background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                    stop:0 rgba(255,255,255,255),
                    stop:1 rgba(252,253,255,255));
                border: 1px solid rgba(230,233,238,255);
                border-radius: 16px;
            }
            '''
        )
        apply_soft_shadow(self, blur=30, y=10, alpha=30)


class NavButton(QPushButton):
    def __init__(self, text: str, parent: Optional[QWidget] = None) -> None:
        super().__init__(text, parent)
        self.setCursor(Qt.PointingHandCursor)
        self.setCheckable(True)
        self.setMinimumHeight(44)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

        self._hover = 0.0
        self._press = 0.0

        self._hover_anim = QPropertyAnimation(self, b"hoverProgress", self)
        self._hover_anim.setDuration(170)
        self._hover_anim.setEasingCurve(QEasingCurve.OutCubic)

        self._press_anim = QPropertyAnimation(self, b"pressProgress", self)
        self._press_anim.setDuration(120)
        self._press_anim.setEasingCurve(QEasingCurve.OutCubic)

        f = self.font()
        f.setPointSize(10)
        f.setWeight(QFont.Medium)
        self.setFont(f)

        self.setStyleSheet("QPushButton{border:none;background:transparent;padding:0;margin:0;}")

    def enterEvent(self, event):
        self._hover_anim.stop()
        self._hover_anim.setEndValue(1.0)
        self._hover_anim.start()
        super().enterEvent(event)

    def leaveEvent(self, event):
        self._hover_anim.stop()
        self._hover_anim.setEndValue(0.0)
        self._hover_anim.start()
        super().leaveEvent(event)

    def mousePressEvent(self, event):
        self._press_anim.stop()
        self._press_anim.setEndValue(1.0)
        self._press_anim.start()
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        self._press_anim.stop()
        self._press_anim.setEndValue(0.0)
        self._press_anim.start()
        super().mouseReleaseEvent(event)

    def getHoverProgress(self) -> float:
        return self._hover

    def setHoverProgress(self, v: float) -> None:
        self._hover = float(v)
        self.update()

    hoverProgress = Property(float, getHoverProgress, setHoverProgress)

    def getPressProgress(self) -> float:
        return self._press

    def setPressProgress(self, v: float) -> None:
        self._press = float(v)
        self.update()

    pressProgress = Property(float, getPressProgress, setPressProgress)

    def paintEvent(self, _event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)

        r = self.rect().adjusted(10, 6, -10, -6)
        radius = 14

        if self.isEnabled():
            for dy, alpha in ((2, 18), (4, 10)):
                sr = r.adjusted(0, dy, 0, dy)
                sp = QPainterPath()
                sp.addRoundedRect(sr, radius, radius)
                p.fillPath(sp, QColor(0, 0, 0, alpha))

        base = THEME["panel2"]
        hover_tint = blend(THEME["hover"], THEME["accent"], 0.06)

        if self.isChecked():
            active_base = blend(base, THEME["accent"], 0.07)
            bg = blend(active_base, hover_tint, 0.40 + 0.30 * self._hover)
        else:
            bg = blend(base, hover_tint, self._hover)

        bg = blend(bg, THEME["press"], min(1.0, self._press * 0.90))

        path = QPainterPath()
        path.addRoundedRect(r, radius, radius)
        p.fillPath(path, bg)

        pen_base = blend(THEME["border"], qcolor(255, 255, 255), 0.15)
        pen_col = blend(pen_base, THEME["accent"], 0.08 * self._hover)
        p.setPen(QPen(pen_col, 1))
        p.drawPath(path)

        if self.isChecked():
            strip = r.adjusted(0, 3, -r.width() + 4, -3)
            strip_path = QPainterPath()
            strip_path.addRoundedRect(strip, 2, 2)
            p.fillPath(strip_path, THEME["accent"])

        f = self.font()
        f.setWeight(QFont.DemiBold if self.isChecked() else QFont.Medium)
        p.setFont(f)

        if self.isChecked():
            pen = THEME["text"]
        else:
            base_pen = blend(THEME["text"], THEME["muted"], 0.35)
            pen = blend(base_pen, THEME["text"], 0.18 * self._hover)
        p.setPen(pen)

        text_rect = r.adjusted(16, 0, -8, 0)
        p.drawText(text_rect, Qt.AlignVCenter | Qt.AlignLeft, self.text())


def logo_widget(parent: QWidget, title_fallback: str = "DataTool") -> QWidget:
    box = QFrame(parent)
    box.setObjectName("LogoBox")
    box.setAttribute(Qt.WA_StyledBackground, True)
    box.setStyleSheet(
        '''
        QFrame#LogoBox{
            background: rgba(255,255,255,0);
            border: 1px solid rgba(230,233,238,160);
            border-radius: 14px;
        }
        '''
    )

    from PySide6.QtWidgets import QVBoxLayout
    lb = QVBoxLayout(box)
    lb.setContentsMargins(10, 8, 10, 8)
    lb.setSpacing(0)

    logo = QLabel()
    logo.setAlignment(Qt.AlignLeft | Qt.AlignTop)
    logo.setStyleSheet("background: transparent; border: none;")

    logo_path = Path(__file__).resolve().parent / "datatool_logo.png"
    if logo_path.exists():
        pix = QPixmap(str(logo_path)).scaledToHeight(58, Qt.SmoothTransformation)
        logo.setPixmap(pix)
        logo.setFixedSize(pix.size())
    else:
        logo.setText(title_fallback)
        logo.setStyleSheet("color: rgba(28,31,35,255); background: transparent; border: none;")
        f = logo.font()
        f.setPointSize(14)
        f.setWeight(QFont.DemiBold)
        logo.setFont(f)

    lb.addWidget(logo)
    return box
