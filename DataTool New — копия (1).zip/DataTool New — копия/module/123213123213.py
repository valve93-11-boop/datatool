# FrodMRM2.py
import sys
import os
import pandas as pd
import re
from datetime import datetime
from PySide6.QtWidgets import (QApplication, QMainWindow, QVBoxLayout, QHBoxLayout,
                               QWidget, QPushButton, QLabel, QFileDialog, QFrame,
                               QProgressBar, QMessageBox, QDateEdit)
from PySide6.QtCore import Qt, QThread, Signal, QDate
from PySide6.QtGui import QFont, QColor
import subprocess
import tempfile

# ------------------------- ТЕМА: DataTool Suite -------------------------
def apply_datatool_theme(app: QApplication, window: QMainWindow) -> None:
    """
    Единый стиль в духе главного окна DataTool:
    - общий светло-голубой фон (#dbe7ff)
    - карточки с мягким градиентом
    - кнопки/поля со скруглениями
    - спокойные цвета, без тёмных заливок
    """
    stylesheet = """
    /* общий фон */
    QMainWindow, QWidget, QDialog {
        background-color: #dbe7ff;
    }

    /* Заголовки/лейблы — просто читабельный текст */
    QLabel {
        color: #0f172a;
        font-size: 13px;
        font-weight: 500;
        background-color: transparent;
        border: none;
        padding: 0px;
    }

    /* Крупный титул вверху — зададим через setStyleSheet точечно */

    /* Карточка для блока дат (используем уже заданный класс) */
    QFrame[class="date-frame"] {
        background: qlineargradient(
            x1:0, y1:0, x2:0, y2:1,
            stop:0 #f9fbff,
            stop:1 #e3edff
        );
        border: 1px solid rgba(0,0,0,0.2);
        border-radius: 12px;
        padding: 14px;
        margin: 8px;
    }

    /* Поля ввода дат и прочие инпуты */
    QDateEdit,
    QLineEdit,
    QTextEdit,
    QPlainTextEdit,
    QComboBox,
    QSpinBox,
    QDoubleSpinBox {
        background-color: #ffffff;
        border: 1px solid rgba(0,0,0,0.35);
        border-radius: 6px;
        padding: 6px 8px;
        color: #0f172a;
        selection-background-color: #cbd9ff;
        selection-color: #0f172a;
        font-size: 13px;
    }

    /* Кнопки действий */
    QPushButton {
        background: qlineargradient(
            x1:0, y1:0, x2:0, y2:1,
            stop:0 #ffffff,
            stop:1 #eef1f7
        );
        border: 1px solid rgba(0,0,0,0.35);
        border-radius: 8px;
        padding: 10px 16px;
        color: #0f172a;
        font-size: 13px;
        font-weight: 600;
        min-width: 280px;
        margin: 6px;
    }
    QPushButton:hover {
        background: qlineargradient(
            x1:0, y1:0, x2:0, y2:1,
            stop:0 #ffffff,
            stop:1 #e2e8f9
        );
        border: 1px solid rgba(0,0,0,0.55);
    }
    QPushButton:disabled {
        background-color: #f1f5ff;
        color: #94a3b8;
        border: 1px solid rgba(0,0,0,0.15);
    }

    /* Прогресс-бар */
    QProgressBar {
        border: 1px solid rgba(0,0,0,0.25);
        border-radius: 6px;
        background-color: #eef2ff;
        margin: 10px;
        height: 20px;
        color: #0f172a;
        text-align: center;
    }
    QProgressBar::chunk {
        background-color: #3b82f6;
        border-radius: 5px;
    }
    """
    app.setStyleSheet(stylesheet)

    # подстраховка от тёмных "дырок"
    pal = window.palette()
    pal.setColor(window.backgroundRole(), QColor("#dbe7ff"))
    window.setPalette(pal)
    window.setAutoFillBackground(True)


class FileProcessor(QThread):
    progress = Signal(int)
    message = Signal(str)
    finished = Signal(pd.DataFrame, pd.DataFrame, int, str)  # main_df, file2_copy, fraud_count, output_path
    error = Signal(str)

    def __init__(self, file1_path, file2_path, start_date, end_date):
        super().__init__()
        self.file1_path = file1_path
        self.file2_path = file2_path
        self.start_date = start_date
        self.end_date = end_date

    def run(self):
        try:
            # Обработка файла 1 - выданные планшеты
            self.progress.emit(10)

            df1 = self.process_file1()
            if df1.empty:
                self.error.emit("В файле выданных планшетов не найдено данных")
                return

            self.progress.emit(40)

            # Обработка файла 2 - версии ОС
            self.progress.emit(50)

            df2 = self.process_file2()
            file2_full_copy = self.get_file2_full_copy()

            self.progress.emit(70)

            # Объединение файлов
            self.progress.emit(80)

            result_df = self.merge_data(df1, df2)

            # Поиск записей с "11" в ВерсияОС
            fraud_df = result_df[result_df['ВерсияОС'].astype(str).str.contains('11', na=False)]
            fraud_count = len(fraud_df)

            # Сохранение результата
            output_path = self.save_result(result_df, file2_full_copy)

            self.progress.emit(100)
            self.finished.emit(result_df, file2_full_copy, fraud_count, output_path)

        except Exception as e:
            self.error.emit(f"Ошибка обработки: {str(e)}")

    def process_file1(self):
        """Обработка файла с выданными планшетами"""
        # Чтение файла
        if self.file1_path.endswith('.xlsx'):
            df = pd.read_excel(self.file1_path)
        else:
            try:
                df = pd.read_csv(self.file1_path, encoding='utf-8', sep=';')
            except:
                df = pd.read_csv(self.file1_path, encoding='cp1251', sep=';')

        # Поиск столбца с решением
        solution_col = self.find_column(df, ['решение', 'solution', 'результат', 'result'])
        if not solution_col:
            return pd.DataFrame()

        # Функция для извлечения выданных планшетов
        def extract_issued_tablets(solution_text):
            if not isinstance(solution_text, str):
                return []

            if '#demontazh' in solution_text:
                solution_text = solution_text.split('#demontazh')[0]

            pattern = r'#montazh_SN[^#]*#10121673#([A-Z0-9]{17,25})'
            matches = re.findall(pattern, solution_text)
            valid_sn = [sn for sn in matches if sn.startswith('PTST')]
            return list(set(valid_sn))

        # Извлечение планшетов
        df['issued_tablets'] = df[solution_col].apply(extract_issued_tablets)

        # Поиск нужных колонок
        request_col = self.find_column(df, ['запрос', 'request', 'требование'])
        date_col = self.find_column(df, ['дата и время окончания работ', 'дата окончания', 'окончание'])
        terbank_col = self.find_column(df, ['тербанк', 'terbank', 'филиал', 'branch'])

        # Создание результата
        result_rows = []
        seen_combinations = set()

        for idx, row in df.iterrows():
            sn_list = row['issued_tablets']
            if sn_list:
                request_value = str(row.get(request_col, '')) if request_col else f"ROW_{idx}"

                for sn in sn_list:
                    unique_key = f"{request_value}_{sn}"
                    if unique_key not in seen_combinations:
                        seen_combinations.add(unique_key)

                        new_row = {
                            'Запрос': request_value,
                            'Дата и время окончания работ': row.get(date_col, '') if date_col else '',
                            'Решение': row.get(solution_col, ''),
                            'Тербанк': row.get(terbank_col, '') if terbank_col else '',
                            'S/N': sn
                        }
                        result_rows.append(new_row)

        result_df = pd.DataFrame(result_rows)
        if not result_df.empty:
            column_order = ['Запрос', 'Дата и время окончания работ', 'Решение', 'Тербанк', 'S/N']
            column_order = [col for col in column_order if col in result_df.columns]
            result_df = result_df[column_order]

        return result_df

    def process_file2(self):
        """Обработка файла с версиями ОС"""
        # Чтение файла
        if self.file2_path.endswith('.xlsx'):
            df = pd.read_excel(self.file2_path)
        else:
            try:
                df = pd.read_csv(self.file2_path, encoding='utf-8', sep=';')
            except:
                df = pd.read_csv(self.file2_path, encoding='cp1251', sep=';')

        # Поиск нужных колонок
        status_col = self.find_column(df, ['статус устройства', 'статус', 'status'])
        sn_col = self.find_column(df, ['серийныйномер', 'серийный номер', 'serial'])
        os_col = self.find_column(df, ['версияос', 'версия ос', 'os version'])
        date_col = self.find_column(df, ['датарегистрации', 'дата регистрации', 'registration date'])

        if not all([status_col, sn_col, os_col, date_col]):
            return pd.DataFrame()

        # Фильтрация по статусу "Control"
        df = df[df[status_col].astype(str).str.lower() == 'control']

        # Фильтрация по дате
        if self.start_date and self.end_date:
            try:
                df[date_col] = pd.to_datetime(df[date_col], errors='coerce')
                mask = (df[date_col] >= pd.to_datetime(self.start_date)) & (df[date_col] <= pd.to_datetime(self.end_date))
                df = df[mask]
            except:
                pass

        # Выбор нужных колонок
        result_df = df[[sn_col, os_col, date_col]].copy()
        result_df.columns = ['S/N', 'ВерсияОС', 'ДатаРегистрации']

        return result_df

    def get_file2_full_copy(self):
        """Полная копия файла 2"""
        if self.file2_path.endswith('.xlsx'):
            return pd.read_excel(self.file2_path)
        else:
            try:
                return pd.read_csv(self.file2_path, encoding='utf-8', sep=';')
            except:
                return pd.read_csv(self.file2_path, encoding='cp1251', sep=';')

    def merge_data(self, df1, df2):
        """Объединение данных из двух файлов"""
        if df2.empty:
            # Если файл 2 пустой, возвращаем только файл 1 с пустыми колонками
            df1['ВерсияОС'] = ''
            df1['ДатаРегистрации'] = ''
            return df1
        else:
            # Объединение по S/N
            merged_df = pd.merge(df1, df2, on='S/N', how='left')
            return merged_df

    def save_result(self, result_df, file2_full_copy):
        """Сохранение результата с несколькими листами"""
        # Сохраняем в директорию файла 1
        output_dir = os.path.dirname(self.file1_path)
        base_name = os.path.splitext(os.path.basename(self.file1_path))[0]
        output_path = os.path.join(output_dir, f"{base_name}_объединенный_результат.xlsx")

        with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
            # Основной лист с объединенными данными
            result_df.to_excel(writer, sheet_name='Объединенные данные', index=False)

            # Лист с результатами проверки (где ВерсияОС содержит "11")
            fraud_df = result_df[result_df['ВерсияОС'].astype(str).str.contains('11', na=False)]
            fraud_df.to_excel(writer, sheet_name='Результаты проверки', index=False)

            # Полная копия файла 2
            if file2_full_copy is not None and not file2_full_copy.empty:
                file2_full_copy.to_excel(writer, sheet_name='SberUser', index=False)

        return output_path

    def find_column(self, df, possible_names):
        """Поиск колонки по возможным названиям"""
        for col in df.columns:
            col_lower = str(col).lower()
            for name in possible_names:
                if name in col_lower:
                    return col
        return None


class FileUploader(QMainWindow):
    def __init__(self):
        super().__init__()
        self.file1_path = None
        self.file2_path = None
        self.start_date = None
        self.end_date = None
        self.processed_data = None
        self.file2_full_copy = None
        self.fraud_count = 0
        self.output_path = None
        self.initUI()

    def initUI(self):
        self.setWindowTitle("Обработка выданных планшетов")
        self.setFixedSize(500, 450)

        # СВОЙ локальный стиль полностью заменён общей темой — оставим лишь точечные правки ниже

        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        layout = QVBoxLayout(central_widget)
        layout.setSpacing(8)
        layout.setContentsMargins(20, 20, 20, 20)

        # Заголовок
        title_label = QLabel("Обработка выданных планшетов")
        title_label.setAlignment(Qt.AlignCenter)
        title_label.setFont(QFont("Arial", 16, QFont.Bold))
        # стиль заголовка — тёмный текст без плашек
        title_label.setStyleSheet("""
            QLabel {
                color: #0f172a;
                font-size: 16px;
                font-weight: 700;
                background: transparent;
            }
        """)
        layout.addWidget(title_label)

        # Диапазон дат
        date_frame = QFrame()
        date_frame.setProperty("class", "date-frame")  # важно для "карточки"
        date_layout = QVBoxLayout(date_frame)

        date_title = QLabel("Диапазон регистрации устройств:")
        date_title.setAlignment(Qt.AlignCenter)
        date_title.setStyleSheet("""
            QLabel {
                color: #0f172a;
                font-size: 13px;
                font-weight: 600;
            }
        """)
        date_layout.addWidget(date_title)

        # Контейнер для дат
        dates_container = QHBoxLayout()

        # Начальная дата
        start_date_container = QVBoxLayout()
        start_label = QLabel("Начальная дата:")
        start_label.setAlignment(Qt.AlignCenter)
        start_date_container.addWidget(start_label)

        self.start_date_edit = QDateEdit()
        self.start_date_edit.setDate(QDate.currentDate().addDays(-30))
        self.start_date_edit.setCalendarPopup(True)
        self.start_date_edit.setDisplayFormat("dd.MM.yyyy")
        self.start_date_edit.setMinimumDate(QDate(2020, 1, 1))
        self.start_date_edit.setMaximumDate(QDate(2030, 12, 31))
        start_date_container.addWidget(self.start_date_edit)

        # Конечная дата
        end_date_container = QVBoxLayout()
        end_label = QLabel("Конечная дата:")
        end_label.setAlignment(Qt.AlignCenter)
        end_date_container.addWidget(end_label)

        self.end_date_edit = QDateEdit()
        self.end_date_edit.setDate(QDate.currentDate())
        self.end_date_edit.setCalendarPopup(True)
        self.end_date_edit.setDisplayFormat("dd.MM.yyyy")
        self.end_date_edit.setMinimumDate(QDate(2020, 1, 1))
        self.end_date_edit.setMaximumDate(QDate(2030, 12, 31))
        end_date_container.addWidget(self.end_date_edit)

        dates_container.addLayout(start_date_container)
        dates_container.addLayout(end_date_container)
        date_layout.addLayout(dates_container)

        layout.addWidget(date_frame)

        # Кнопка загрузки файла 1
        self.file1_button = QPushButton("Загрузить список выданных планшетов")
        self.file1_button.clicked.connect(self.load_file1)
        layout.addWidget(self.file1_button)

        # Кнопка загрузки файла 2
        self.file2_button = QPushButton("Загрузить файл с версиями ОС")
        self.file2_button.clicked.connect(self.load_file2)
        layout.addWidget(self.file2_button)

        # Статус файлов
        self.file1_status = QLabel("Файл 1: не загружен")
        self.file1_status.setAlignment(Qt.AlignCenter)
        self.file2_status = QLabel("Файл 2: не загружен")
        self.file2_status.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.file1_status)
        layout.addWidget(self.file2_status)

        # Прогресс бар
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        layout.addWidget(self.progress_bar)

        # Статус обработки
        self.status_label = QLabel("")
        self.status_label.setWordWrap(True)
        self.status_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.status_label)

        layout.addStretch()

    def load_file1(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Выберите файл выданных планшетов", "",
            "Excel Files (*.xlsx *.xls);;CSV Files (*.csv);;All Files (*)"
        )
        if file_path:
            self.file1_path = file_path
            self.file1_status.setText(f"Файл 1: {os.path.basename(file_path)}")
            self.file1_status.setStyleSheet("color: #166534;")  # зелёный текст
            self.check_auto_process()

    def load_file2(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Выберите файл с версиями ОС", "",
            "Excel Files (*.xlsx *.xls);;CSV Files (*.csv);;All Files (*)"
        )
        if file_path:
            self.file2_path = file_path
            self.file2_status.setText(f"Файл 2: {os.path.basename(file_path)}")
            self.file2_status.setStyleSheet("color: #166534;")
            self.check_auto_process()

    def check_auto_process(self):
        """Автоматически запускает обработку при загрузке обоих файлов"""
        if self.file1_path and self.file2_path:
            self.status_label.setText("Оба файла загружены, начинается обработка...")
            self.process_files()

    def process_files(self):
        """Обработка обоих файлов"""
        if not self.file1_path or not self.file2_path:
            return

        # Получаем даты
        self.start_date = self.start_date_edit.date().toString("yyyy-MM-dd")
        self.end_date = self.end_date_edit.date().toString("yyyy-MM-dd")

        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)

        # Запускаем обработку
        self.processor = FileProcessor(self.file1_path, self.file2_path, self.start_date, self.end_date)
        self.processor.progress.connect(self.progress_bar.setValue)
        self.processor.message.connect(self.update_status)
        self.processor.finished.connect(self.on_processing_finished)
        self.processor.error.connect(self.on_processing_error)
        self.processor.start()

    def update_status(self, message):
        self.status_label.setText(message)

    def on_processing_finished(self, result_df, file2_full_copy, fraud_count, output_path):
        self.processed_data = result_df
        self.file2_full_copy = file2_full_copy
        self.fraud_count = fraud_count
        self.output_path = output_path
        self.progress_bar.setVisible(False)

        if not result_df.empty:
            self.status_label.setText("✓ Обработка завершена успешно!")
            self.ask_create_email()
        else:
            self.status_label.setText("⚠ Обработка завершена, но данные не найдены")

    def on_processing_error(self, error_message):
        self.progress_bar.setVisible(False)
        self.status_label.setText(f"❌ Ошибка: {error_message}")
        QMessageBox.critical(self, "Ошибка", error_message)

    def ask_create_email(self):
        """Спрашивает о создании письма"""
        reply = QMessageBox.question(
            self,
            "Сформировать письмо в СБС",
            f"Обработка завершена!\n\nВыявлено отклонений: {self.fraud_count}\n\nСформировать письмо в СБС?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.Yes
        )

        if reply == QMessageBox.Yes:
            self.create_email()
        else:
            self.close()

    def create_email(self):
        """Создание письма в Outlook с вложением"""
        try:
            # Формируем период
            start_date_str = self.start_date_edit.date().toString("dd.MM.yyyy")
            end_date_str = self.end_date_edit.date().toString("dd.MM.yyyy")
            period = f"{start_date_str} - {end_date_str}"

            # Тема письма
            subject = f"ФРОД МРМ за период {period}"

            # Текст письма
            body = f"Добрый день, коллеги!\n\nЗа отчетный период выявлено {self.fraud_count} отклонений."

            # Создаем AppleScript для отправки письма через Outlook (macOS)
            applescript = f'''
            tell application "Microsoft Outlook"
                set newMessage to make new outgoing message with properties {{subject:"{subject}", content:"{body}"}}
                make new attachment at newMessage with properties {{file:POSIX file "{self.output_path}"}}
                open newMessage
            end tell
            '''

            process = subprocess.Popen(['osascript', '-e', applescript],
                                       stdout=subprocess.PIPE,
                                       stderr=subprocess.PIPE)
            stdout, stderr = process.communicate()

            if process.returncode == 0:
                QMessageBox.information(self, "Успех", "Письмо создано в Outlook с вложением!")
                self.close()
            else:
                # Если Outlook не доступен, пробуем через стандартный почтовый клиент
                self.create_email_fallback(subject, body)

        except Exception:
            # Fallback метод
            self.create_email_fallback(subject, body)

    def create_email_fallback(self, subject, body):
        """Резервный метод создания письма через стандартный почтовый клиент"""
        try:
            subject_encoded = subject.replace(' ', '%20')
            body_encoded = body.replace(' ', '%20').replace('\n', '%0A')

            # Временная копия файла
            temp_dir = tempfile.gettempdir()
            temp_file = os.path.join(temp_dir, os.path.basename(self.output_path))

            import shutil
            shutil.copy2(self.output_path, temp_file)

            outlook_url = f"mailto:?subject={subject_encoded}&body={body_encoded}"
            subprocess.run(['open', outlook_url])

            QMessageBox.information(self, "Успех",
                                    f"Письмо создано в почтовом клиенте!\n\n"
                                    f"Файл для вложения сохранен:\n{temp_file}\n\n"
                                    f"Пожалуйста, добавьте его вручную к письму.")
            self.close()

        except Exception as e:
            QMessageBox.critical(self, "Ошибка",
                                 f"Не удалось создать письмо: {str(e)}\n\n"
                                 f"Файл результата сохранен:\n{self.output_path}\n\n"
                                 f"Создайте письмо вручную и прикрепите этот файл.")

def main():
    app = QApplication(sys.argv)
    # Важно: применяем тему после создания окна
    window = FileUploader()
    apply_datatool_theme(app, window)

    window.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
