import sys
import pandas as pd
import re
from datetime import datetime, timedelta
from difflib import SequenceMatcher
from PySide6.QtWidgets import (QApplication, QMainWindow, QVBoxLayout,
                               QHBoxLayout, QPushButton, QLabel,
                               QWidget, QFileDialog, QMessageBox,
                               QTableWidget, QTableWidgetItem,
                               QHeaderView, QStackedWidget, QComboBox,
                               QScrollArea, QGridLayout, QSizePolicy)
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QFont, QColor, QPainter


class ServiceCodesWidget(QWidget):
    def __init__(self, service_codes_data, service_name, parent=None):
        super().__init__(parent)
        self.service_codes_data = service_codes_data
        self.service_name = service_name
        self.parent_ref = parent
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()
        # Заголовок
        title_label = QLabel(f"🔧 Коды ARM для услуги: {self.service_name}")
        title_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 16px;
            font-weight: bold;
            padding: 12px;
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #3498DB, stop:1 #2980B9);
            border-radius: 8px;
            color: white;
        }
        """)
        layout.addWidget(title_label)

        # Общая статистика
        total_codes = len(self.service_codes_data)
        total_requests = sum(stats['count'] for stats in self.service_codes_data.values())
        stats_layout = QHBoxLayout()
        codes_label = QLabel(f"📊 Уникальных кодов: {total_codes}")
        codes_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 12px;
            padding: 10px;
            background-color: #EBF5FB;
            border-radius: 6px;
            font-weight: bold;
            border: 2px solid #3498DB;
        }
        """)
        requests_label = QLabel(f"🚀 Всего применений: {total_requests}")
        requests_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 12px;
            padding: 10px;
            background-color: #EAFAF1;
            border-radius: 6px;
            font-weight: bold;
            border: 2px solid #27AE60;
        }
        """)
        stats_layout.addWidget(codes_label)
        stats_layout.addWidget(requests_label)
        stats_layout.addStretch()
        layout.addLayout(stats_layout)

        # Таблица с кодами
        self.codes_table = QTableWidget()
        self.codes_table.setColumnCount(4)
        self.codes_table.setHorizontalHeaderLabels(["🔑 Код ARM", "📝 Название работы", "🆔 ID услуги", "📊 Использований"])
        # Заполняем таблицу данными
        self.populate_codes_table()
        # Настройка стиля таблицы
        self.codes_table.setStyleSheet("""
        QTableWidget {
            background-color: white;
            border: 2px solid #3498DB;
            border-radius: 8px;
            gridline-color: #D6EAF8;
            color: #2C3E50;
        }
        QTableWidget::item {
            padding: 8px;
            border-bottom: 1px solid #D6EAF8;
            color: #2C3E50;
        }
        QTableWidget::item:selected {
            background-color: #3498DB;
            color: white;
        }
        QHeaderView::section {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #2980B9, stop:1 #2471A3);
            color: white;
            font-weight: bold;
            padding: 10px;
            border: none;
            font-size: 12px;
        }
        """)
        self.codes_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.codes_table.cellDoubleClicked.connect(self.on_code_double_click)
        layout.addWidget(self.codes_table)

        # Кнопка назад
        back_btn = QPushButton("⬅️ Назад")
        back_btn.setStyleSheet("""
        QPushButton {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #E74C3C, stop:1 #C0392B);
            color: white;
            border: none;
            border-radius: 6px;
            padding: 12px;
            font-size: 14px;
            font-weight: bold;
        }
        QPushButton:hover {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #C0392B, stop:1 #A93226);
        }
        QPushButton:pressed {
            background: #922B21;
        }
        """)
        back_btn.clicked.connect(self.go_back)
        layout.addWidget(back_btn)
        self.setLayout(layout)

    def populate_codes_table(self):
        codes_data = []
        for code, stats in self.service_codes_data.items():
            codes_data.append({
                'code': code,
                'work_name': stats['work_name'],
                'service_id': stats['service_id'],
                'count': stats['count']
            })
        # Сортируем по количеству использований (убывание)
        codes_data.sort(key=lambda x: x['count'], reverse=True)
        self.codes_table.setRowCount(len(codes_data))
        for row, item in enumerate(codes_data):
            self.codes_table.setItem(row, 0, QTableWidgetItem(item['code']))
            work_name_item = QTableWidgetItem(item['work_name'])
            work_name_item.setToolTip(item['work_name'])
            self.codes_table.setItem(row, 1, work_name_item)
            self.codes_table.setItem(row, 2, QTableWidgetItem(item['service_id']))
            count_item = QTableWidgetItem(str(item['count']))
            count_item.setData(Qt.UserRole, {'code': item['code'], 'service_name': self.service_name})
            self.codes_table.setItem(row, 3, count_item)

    def on_code_double_click(self, row, column):
        """Обработка двойного клика по количеству использований"""
        if column == 3:  # Колонка "Использований"
            item = self.codes_table.item(row, column)
            if item and item.data(Qt.UserRole):
                code_data = item.data(Qt.UserRole)
                self.parent_ref.show_service_code_requests(code_data['code'], code_data['service_name'])

    def go_back(self):
        self.parent_ref.show_service_details(self.service_name)


class ServiceDetailWidget(QWidget):
    def __init__(self, service_data, parent=None):
        super().__init__(parent)
        self.service_data = service_data
        self.parent_ref = parent
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()
        # Заголовок
        title_label = QLabel(f"📊 Статистика по кодам закрытия: {self.service_data['service_name']}")
        title_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 16px;
            font-weight: bold;
            padding: 12px;
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #3498DB, stop:1 #2980B9);
            border-radius: 8px;
            color: white;
        }
        """)
        layout.addWidget(title_label)

        # Информация об услуге
        info_layout = QVBoxLayout()
        name_label = QLabel(f"🏷️ Название услуги: {self.service_data['service_name']}")
        name_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 14px;
            font-weight: bold;
            padding: 10px;
            background-color: #EBF5FB;
            border-radius: 6px;
            border: 2px solid #3498DB;
        }
        """)
        name_label.setWordWrap(True)
        info_layout.addWidget(name_label)
        layout.addLayout(info_layout)

        # Статистика
        stats_layout = QHBoxLayout()
        requests_label = QLabel(f"📨 Всего заявок: {self.service_data['total_requests']}")
        requests_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 12px;
            padding: 10px;
            background-color: #EAFAF1;
            border-radius: 6px;
            font-weight: bold;
            border: 2px solid #27AE60;
        }
        """)
        codes_label = QLabel(f"🔑 Уникальных кодов: {len(self.service_data['arm_codes'])}")
        codes_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 12px;
            padding: 10px;
            background-color: #EBF5FB;
            border-radius: 6px;
            font-weight: bold;
            border: 2px solid #3498DB;
        }
        """)
        period_label = QLabel(f"📅 Период: {self.service_data['period']}")
        period_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 12px;
            padding: 10px;
            background-color: #FEF9E7;
            border-radius: 6px;
            font-weight: bold;
            border: 2px solid #F39C12;
        }
        """)
        stats_layout.addWidget(requests_label)
        stats_layout.addWidget(codes_label)
        stats_layout.addWidget(period_label)
        stats_layout.addStretch()
        layout.addLayout(stats_layout)

        # Таблица с кодами ARM
        codes_label = QLabel("🔧 Коды ARM, использованные в услуге:")
        codes_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 14px;
            font-weight: bold;
            padding: 10px;
            background-color: #F8F9F9;
            border-radius: 6px;
            border: 2px solid #BDC3C7;
        }
        """)
        layout.addWidget(codes_label)

        self.codes_table = QTableWidget()
        self.codes_table.setColumnCount(4)
        self.codes_table.setHorizontalHeaderLabels(["🔑 Код ARM", "📝 Название работы", "🆔 ID услуги", "📊 Использований"])
        # Заполняем таблицу данными
        self.populate_codes_table()
        # Настройка стиля таблицы
        self.codes_table.setStyleSheet("""
        QTableWidget {
            background-color: white;
            border: 2px solid #3498DB;
            border-radius: 8px;
            gridline-color: #D6EAF8;
            color: #2C3E50;
        }
        QTableWidget::item {
            padding: 8px;
            border-bottom: 1px solid #D6EAF8;
            color: #2C3E50;
        }
        QTableWidget::item:selected {
            background-color: #3498DB;
            color: white;
        }
        QHeaderView::section {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #2980B9, stop:1 #2471A3);
            color: white;
            font-weight: bold;
            padding: 10px;
            border: none;
            font-size: 12px;
        }
        """)
        self.codes_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.codes_table.cellDoubleClicked.connect(self.on_code_double_click)
        layout.addWidget(self.codes_table)

        # Кнопка назад
        back_btn = QPushButton("⬅️ Назад")
        back_btn.setStyleSheet("""
        QPushButton {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #E74C3C, stop:1 #C0392B);
            color: white;
            border: none;
            border-radius: 6px;
            padding: 12px;
            font-size: 14px;
            font-weight: bold;
        }
        QPushButton:hover {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #C0392B, stop:1 #A93226);
        }
        QPushButton:pressed {
            background: #922B21;
        }
        """)
        back_btn.clicked.connect(self.go_back)
        layout.addWidget(back_btn)
        self.setLayout(layout)

    def populate_codes_table(self):
        codes_data = []
        for code, stats in self.service_data['arm_codes'].items():
            codes_data.append({
                'code': code,
                'work_name': stats['work_name'],
                'service_id': stats['service_id'],
                'count': stats['count']
            })
        # Сортируем по количеству использований (убывание)
        codes_data.sort(key=lambda x: x['count'], reverse=True)
        self.codes_table.setRowCount(len(codes_data))
        for row, item in enumerate(codes_data):
            self.codes_table.setItem(row, 0, QTableWidgetItem(item['code']))
            work_name_item = QTableWidgetItem(item['work_name'])
            work_name_item.setToolTip(item['work_name'])
            self.codes_table.setItem(row, 1, work_name_item)
            self.codes_table.setItem(row, 2, QTableWidgetItem(item['service_id']))
            count_item = QTableWidgetItem(str(item['count']))
            count_item.setData(Qt.UserRole, {'code': item['code'], 'service_name': self.service_data['service_name']})
            self.codes_table.setItem(row, 3, count_item)

    def on_code_double_click(self, row, column):
        """Обработка двойного клика по количеству использований"""
        if column == 3:  # Колонка "Использований"
            item = self.codes_table.item(row, column)
            if item and item.data(Qt.UserRole):
                code_data = item.data(Qt.UserRole)
                self.parent_ref.show_service_code_requests(code_data['code'], code_data['service_name'])

    def go_back(self):
        self.parent_ref.show_service_stats()


class ServiceStatsWidget(QWidget):
    def __init__(self, service_stats, parent=None):
        super().__init__(parent)
        self.service_stats = service_stats
        self.parent_ref = parent
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()
        # Заголовок
        title_label = QLabel("📊 Статистика в разрезе услуг")
        title_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 18px;
            font-weight: bold;
            padding: 15px;
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #3498DB, stop:1 #2980B9);
            border-radius: 10px;
            text-align: center;
            color: white;
        }
        """)
        layout.addWidget(title_label)

        # Общая статистика
        total_services = len(self.service_stats)
        total_requests = sum(stats['total_requests'] for stats in self.service_stats.values())
        stats_layout = QHBoxLayout()
        services_label = QLabel(f"🏷️ Уникальных услуг: {total_services}")
        services_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 14px;
            padding: 12px;
            background-color: #EBF5FB;
            border-radius: 6px;
            font-weight: bold;
            border: 2px solid #3498DB;
        }
        """)
        requests_label = QLabel(f"📨 Всего заявок: {total_requests}")
        requests_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 14px;
            padding: 12px;
            background-color: #EAFAF1;
            border-radius: 6px;
            font-weight: bold;
            border: 2px solid #27AE60;
        }
        """)
        stats_layout.addWidget(services_label)
        stats_layout.addWidget(requests_label)
        stats_layout.addStretch()
        layout.addLayout(stats_layout)

        # Таблица с услугами
        self.services_table = QTableWidget()
        self.services_table.setColumnCount(3)
        self.services_table.setHorizontalHeaderLabels(["🏷️ Название услуги", "📊 Заявок", "🔑 Кодов"])
        # Заполняем таблицу данными
        self.populate_services_table()
        # Настройка стиля таблицы
        self.services_table.setStyleSheet("""
        QTableWidget {
            background-color: white;
            border: 2px solid #3498DB;
            border-radius: 8px;
            gridline-color: #D6EAF8;
            font-size: 12px;
        }
        QTableWidget::item {
            padding: 10px;
            border-bottom: 1px solid #D6EAF8;
            color: #2C3E50;
        }
        QTableWidget::item:selected {
            background-color: #3498DB;
            color: white;
        }
        QHeaderView::section {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #2980B9, stop:1 #2471A3);
            color: white;
            font-weight: bold;
            padding: 12px;
            border: none;
            font-size: 13px;
        }
        """)
        self.services_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.services_table.cellDoubleClicked.connect(self.on_service_double_click)
        layout.addWidget(self.services_table)

        # Кнопка назад
        back_btn = QPushButton("⬅️ Назад")
        back_btn.setStyleSheet("""
        QPushButton {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #E74C3C, stop:1 #C0392B);
            color: white;
            border: none;
            border-radius: 6px;
            padding: 12px;
            font-size: 14px;
            font-weight: bold;
        }
        QPushButton:hover {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #C0392B, stop:1 #A93226);
        }
        QPushButton:pressed {
            background: #922B21;
        }
        """)
        back_btn.clicked.connect(self.go_back)
        layout.addWidget(back_btn)
        self.setLayout(layout)

    def populate_services_table(self):
        services_data = []
        for service_code, stats in self.service_stats.items():
            services_data.append({
                'name': stats['service_name'],
                'requests_count': stats['total_requests'],
                'codes_count': len(stats['arm_codes'])
            })
        # Сортируем по количеству заявок (убывание)
        services_data.sort(key=lambda x: x['requests_count'], reverse=True)
        self.services_table.setRowCount(len(services_data))
        for row, item in enumerate(services_data):
            name_item = QTableWidgetItem(item['name'])
            name_item.setToolTip(item['name'])
            self.services_table.setItem(row, 0, name_item)
            self.services_table.setItem(row, 1, QTableWidgetItem(str(item['requests_count'])))
            self.services_table.setItem(row, 2, QTableWidgetItem(str(item['codes_count'])))

    def on_service_double_click(self, row, column):
        """Обработка двойного клика по услуге"""
        service_name = self.services_table.item(row, 0).text()
        self.parent_ref.show_service_details(service_name)

    def go_back(self):
        self.parent_ref.show_main_screen()


# --- остальные классы остаются без изменений ---
# Здесь опущены для экономии места, но они полностью идентичны исходному файлу.
# Изменения только в ExcelAnalyzerApp.show_service_code_requests

class ServiceTerbankKTRWidget(QWidget):
    def __init__(self, service_name, terbank_ktr_data, parent=None):
        super().__init__(parent)
        self.service_name = service_name
        self.terbank_ktr_data = terbank_ktr_data
        self.parent_ref = parent
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()
        # Заголовок
        title_label = QLabel(f"🏢 Средний КТР по тербанкам для услуги: {self.service_name}")
        title_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 16px;
            font-weight: bold;
            padding: 12px;
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #3498DB, stop:1 #2980B9);
            border-radius: 8px;
            color: white;
        }
        """)
        layout.addWidget(title_label)

        # Общая статистика
        total_terbanks = len(self.terbank_ktr_data)
        avg_ktr = sum(self.terbank_ktr_data.values()) / total_terbanks if total_terbanks > 0 else 0
        stats_layout = QHBoxLayout()
        terbanks_label = QLabel(f"🏢 Тербанков: {total_terbanks}")
        terbanks_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 12px;
            padding: 10px;
            background-color: #EBF5FB;
            border-radius: 6px;
            font-weight: bold;
            border: 2px solid #3498DB;
        }
        """)
        ktr_label = QLabel(f"⏱️ Средний КТР по услуге: {avg_ktr:.2f} ч.")
        ktr_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 12px;
            padding: 10px;
            background-color: #EAFAF1;
            border-radius: 6px;
            font-weight: bold;
            border: 2px solid #27AE60;
        }
        """)
        stats_layout.addWidget(terbanks_label)
        stats_layout.addWidget(ktr_label)
        stats_layout.addStretch()
        layout.addLayout(stats_layout)

        # Таблица с тербанками
        self.terbank_table = QTableWidget()
        self.terbank_table.setColumnCount(2)
        self.terbank_table.setHorizontalHeaderLabels(["🏢 Тербанк", "⏱️ Средний КТР (часы)"])
        # Заполняем таблицу данными
        self.populate_terbank_table()
        # Настройка стиля таблицы
        self.terbank_table.setStyleSheet("""
        QTableWidget {
            background-color: white;
            border: 2px solid #3498DB;
            border-radius: 8px;
            gridline-color: #D6EAF8;
            font-size: 12px;
        }
        QTableWidget::item {
            padding: 10px;
            border-bottom: 1px solid #D6EAF8;
            color: #2C3E50;
        }
        QTableWidget::item:selected {
            background-color: #3498DB;
            color: white;
        }
        QHeaderView::section {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #2980B9, stop:1 #2471A3);
            color: white;
            font-weight: bold;
            padding: 12px;
            border: none;
            font-size: 13px;
        }
        """)
        self.terbank_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(self.terbank_table)

        # Кнопка назад
        back_btn = QPushButton("⬅️ Назад")
        back_btn.setStyleSheet("""
        QPushButton {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #E74C3C, stop:1 #C0392B);
            color: white;
            border: none;
            border-radius: 6px;
            padding: 12px;
            font-size: 14px;
            font-weight: bold;
        }
        QPushButton:hover {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #C0392B, stop:1 #A93226);
        }
        QPushButton:pressed {
            background: #922B21;
        }
        """)
        back_btn.clicked.connect(self.go_back)
        layout.addWidget(back_btn)
        self.setLayout(layout)

    def populate_terbank_table(self):
        self.terbank_table.setRowCount(len(self.terbank_ktr_data))
        for row, (terbank, ktr) in enumerate(self.terbank_ktr_data.items()):
            self.terbank_table.setItem(row, 0, QTableWidgetItem(terbank))
            self.terbank_table.setItem(row, 1, QTableWidgetItem(f"{ktr:.2f} ч."))

    def go_back(self):
        self.parent_ref.show_previous_screen()


class ServiceStatsGraphWidget(QWidget):
    def __init__(self, service_stats, employee_stats, parent=None):
        super().__init__(parent)
        self.service_stats = service_stats
        self.employee_stats = employee_stats
        self.parent_ref = parent
        self.current_view = "none"  # "none", "terbank", "service"
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()
        # Заголовок
        title_label = QLabel("📊 Средний КТР(ТБ/Услуга)")
        title_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 18px;
            font-weight: bold;
            padding: 15px;
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #3498DB, stop:1 #2980B9);
            border-radius: 10px;
            text-align: center;
            color: white;
        }
        """)
        layout.addWidget(title_label)

        # Выбор типа отчета
        report_layout = QHBoxLayout()
        report_layout.addStretch()
        report_label = QLabel("📈 Выберите тип отчета:")
        report_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 14px;
            font-weight: bold;
        }
        """)
        self.report_combo = QComboBox()
        self.report_combo.addItems([
            "Выберите отчет...",
            "🏢 Средний КТР по тербанкам",
            "🏷️ Средний КТР по услугам"
        ])
        self.report_combo.setFixedSize(250, 35)
        self.report_combo.setStyleSheet("""
        QComboBox {
            background-color: white;
            border: 2px solid #3498DB;
            border-radius: 6px;
            padding: 5px;
            font-size: 14px;
            color: #2C3E50;
        }
        """)
        self.report_combo.currentTextChanged.connect(self.on_report_changed)
        report_layout.addWidget(report_label)
        report_layout.addWidget(self.report_combo)
        report_layout.addStretch()
        layout.addLayout(report_layout)

        # Область для контента
        self.content_stack = QStackedWidget()
        # Пустой виджет по умолчанию
        self.empty_widget = QLabel("👆 Выберите тип отчета из выпадающего списка")
        self.empty_widget.setStyleSheet("""
        QLabel {
            color: #7F8C8D;
            font-size: 16px;
            font-weight: bold;
            padding: 50px;
            background-color: #F8F9F9;
            border: 2px dashed #BDC3C7;
            border-radius: 10px;
            text-align: center;
        }
        """)
        self.empty_widget.setAlignment(Qt.AlignCenter)
        self.content_stack.addWidget(self.empty_widget)

        # Вид тербанков
        self.terbank_widget = QWidget()
        self.terbank_layout = QVBoxLayout(self.terbank_widget)
        self.content_stack.addWidget(self.terbank_widget)

        # Вид услуг
        self.service_widget = QWidget()
        self.service_layout = QVBoxLayout(self.service_widget)
        self.content_stack.addWidget(self.service_widget)

        layout.addWidget(self.content_stack, 1)  # Коэффициент растяжения 1

        # Кнопка назад
        back_btn = QPushButton("⬅️ Назад")
        back_btn.setStyleSheet("""
        QPushButton {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #E74C3C, stop:1 #C0392B);
            color: white;
            border: none;
            border-radius: 6px;
            padding: 12px;
            font-size: 14px;
            font-weight: bold;
        }
        QPushButton:hover {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #C0392B, stop:1 #A93226);
        }
        QPushButton:pressed {
            background: #922B21;
        }
        """)
        back_btn.clicked.connect(self.go_back)
        layout.addWidget(back_btn)
        self.setLayout(layout)

    def on_report_changed(self, report_type):
        """Обработка изменения типа отчета"""
        if report_type == "🏢 Средний КТР по тербанкам":
            self.show_terbank_ktr()
        elif report_type == "🏷️ Средний КТР по услугам":
            self.show_service_ktr()
        else:
            self.content_stack.setCurrentIndex(0)

    def show_terbank_ktr(self):
        """Показ среднего КТР по тербанкам"""
        # Очищаем предыдущий контент
        self.clear_layout(self.terbank_layout)
        # Расчет статистики КТР по тербанкам
        terbank_ktr_stats = self.calculate_terbank_ktr()
        # Заголовок
        terbank_label = QLabel("🏢 Средний КТР по тербанкам (в часах):")
        terbank_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 16px;
            font-weight: bold;
            padding: 10px;
            background-color: #EBF5FB;
            border-radius: 6px;
            border: 2px solid #3498DB;
        }
        """)
        self.terbank_layout.addWidget(terbank_label)
        # Таблица с тербанками
        terbank_table = QTableWidget()
        terbank_table.setColumnCount(2)
        terbank_table.setHorizontalHeaderLabels(["🏢 Тербанк", "⏱️ Средний КТР (часы)"])
        # Заполняем таблицу данными
        self.populate_terbank_table(terbank_table, terbank_ktr_stats)
        # Настройка стиля таблицы
        terbank_table.setStyleSheet("""
        QTableWidget {
            background-color: white;
            border: 2px solid #3498DB;
            border-radius: 8px;
            gridline-color: #D6EAF8;
            font-size: 12px;
        }
        QTableWidget::item {
            padding: 10px;
            border-bottom: 1px solid #D6EAF8;
            color: #2C3E50;
        }
        QTableWidget::item:selected {
            background-color: #3498DB;
            color: white;
        }
        QHeaderView::section {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #2980B9, stop:1 #2471A3);
            color: white;
            font-weight: bold;
            padding: 12px;
            border: none;
            font-size: 13px;
        }
        """)
        terbank_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.terbank_layout.addWidget(terbank_table, 1)  # Коэффициент растяжения 1
        self.content_stack.setCurrentIndex(1)

    def show_service_ktr(self):
        """Показ среднего КТР по услугам"""
        # Очищаем предыдущий контент
        self.clear_layout(self.service_layout)
        # Расчет статистики КТР по услугам
        service_ktr_stats = self.calculate_service_ktr()
        # Заголовок
        service_label = QLabel("🏷️ Средний КТР по услугам (в часах):")
        service_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 16px;
            font-weight: bold;
            padding: 10px;
            background-color: #EAFAF1;
            border-radius: 6px;
            border: 2px solid #27AE60;
        }
        """)
        self.service_layout.addWidget(service_label)
        # Таблица с услугами
        service_table = QTableWidget()
        service_table.setColumnCount(2)
        service_table.setHorizontalHeaderLabels(["🏷️ Услуга", "⏱️ Средний КТР (часы)"])
        # Заполняем таблицу данными
        self.populate_service_table(service_table, service_ktr_stats)
        # Настройка стиля таблицы
        service_table.setStyleSheet("""
        QTableWidget {
            background-color: white;
            border: 2px solid #27AE60;
            border-radius: 8px;
            gridline-color: #D5F5E3;
            font-size: 12px;
        }
        QTableWidget::item {
            padding: 10px;
            border-bottom: 1px solid #D5F5E3;
            color: #2C3E50;
        }
        QTableWidget::item:selected {
            background-color: #27AE60;
            color: white;
        }
        QHeaderView::section {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #229954, stop:1 #1E8449);
            color: white;
            font-weight: bold;
            padding: 12px;
            border: none;
            font-size: 13px;
        }
        """)
        service_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        service_table.cellDoubleClicked.connect(self.on_service_double_click)
        self.service_layout.addWidget(service_table, 1)  # Коэффициент растяжения 1
        self.content_stack.setCurrentIndex(2)

    def clear_layout(self, layout):
        """Очистка layout"""
        while layout.count():
            child = layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()

    def calculate_terbank_ktr(self):
        """Расчет среднего КТР по тербанкам"""
        terbank_stats = {}
        for employee, stats in self.employee_stats.items():
            terbank = stats['terbank']
            if terbank not in terbank_stats:
                terbank_stats[terbank] = {
                    'total_minutes': 0,
                    'total_requests': 0
                }
            terbank_stats[terbank]['total_minutes'] += stats['total_workload_minutes']
            terbank_stats[terbank]['total_requests'] += stats['total_requests']
        # Рассчитываем средний КТР в часах
        terbank_ktr = {}
        for terbank, stats in terbank_stats.items():
            if stats['total_requests'] > 0:
                avg_minutes = stats['total_minutes'] / stats['total_requests']
                avg_hours = avg_minutes / 60
                terbank_ktr[terbank] = round(avg_hours, 2)
            else:
                terbank_ktr[terbank] = 0
        # Сортируем по убыванию КТР
        return dict(sorted(terbank_ktr.items(), key=lambda x: x[1], reverse=True))

    def calculate_service_ktr(self):
        """Расчет среднего КТР по услугам"""
        service_stats = {}
        # Собираем данные по услугам из employee_stats
        for employee, stats in self.employee_stats.items():
            for request in stats['requests_data']:
                service_name = request.get('service', '')
                if service_name and service_name.strip():
                    if service_name not in service_stats:
                        service_stats[service_name] = {
                            'total_minutes': 0,
                            'total_requests': 0
                        }
                    service_stats[service_name]['total_minutes'] += request.get('workload_minutes', 0)
                    service_stats[service_name]['total_requests'] += 1
        # Рассчитываем средний КТР в часах
        service_ktr = {}
        for service, stats in service_stats.items():
            if stats['total_requests'] > 0:
                avg_minutes = stats['total_minutes'] / stats['total_requests']
                avg_hours = avg_minutes / 60
                service_ktr[service] = round(avg_hours, 2)
            else:
                service_ktr[service] = 0
        # Сортируем по убыванию КТР
        return dict(sorted(service_ktr.items(), key=lambda x: x[1], reverse=True))

    def populate_terbank_table(self, table, terbank_ktr_stats):
        """Заполнение таблицы с тербанками"""
        table.setRowCount(len(terbank_ktr_stats))
        for row, (terbank, ktr) in enumerate(terbank_ktr_stats.items()):
            table.setItem(row, 0, QTableWidgetItem(terbank))
            table.setItem(row, 1, QTableWidgetItem(f"{ktr} ч."))

    def populate_service_table(self, table, service_ktr_stats):
        """Заполнение таблицы с услугами"""
        table.setRowCount(len(service_ktr_stats))
        for row, (service, ktr) in enumerate(service_ktr_stats.items()):
            service_item = QTableWidgetItem(service)
            service_item.setToolTip(service)
            table.setItem(row, 0, service_item)
            table.setItem(row, 1, QTableWidgetItem(f"{ktr} ч."))

    def on_service_double_click(self, row, column):
        """Обработка двойного клика по услуге для показа КТР по тербанкам"""
        if column == 0:  # Клик по названию услуги
            service_name = self.service_layout.itemAt(1).widget().item(row, 0).text()
            self.show_service_terbank_ktr(service_name)

    def show_service_terbank_ktr(self, service_name):
        """Показ КТР по тербанкам для конкретной услуги"""
        # Расчет КТР по тербанкам для указанной услуги
        terbank_ktr_data = self.calculate_service_terbank_ktr(service_name)
        # Создаем виджет для отображения
        service_terbank_widget = ServiceTerbankKTRWidget(service_name, terbank_ktr_data, self.parent_ref)
        # Добавляем в stacked widget и показываем
        self.parent_ref.stacked_widget.addWidget(service_terbank_widget)
        self.parent_ref.stacked_widget.setCurrentWidget(service_terbank_widget)

    def calculate_service_terbank_ktr(self, service_name):
        """Расчет среднего КТР по тербанкам для конкретной услуги"""
        terbank_stats = {}
        # Проходим по всем сотрудникам и их заявкам
        for employee, stats in self.employee_stats.items():
            terbank = stats['terbank']
            # Фильтруем заявки только по указанной услуге
            service_requests = [r for r in stats['requests_data'] if r.get('service', '') == service_name]
            if not service_requests:
                continue
            # Инициализируем статистику для тербанка, если еще не инициализирована
            if terbank not in terbank_stats:
                terbank_stats[terbank] = {
                    'total_minutes': 0,
                    'total_requests': 0
                }
            # Суммируем трудозатраты и количество заявок для этой услуги в тербанке
            for request in service_requests:
                terbank_stats[terbank]['total_minutes'] += request.get('workload_minutes', 0)
                terbank_stats[terbank]['total_requests'] += 1
        # Рассчитываем средний КТР в часах для каждого тербанка
        terbank_ktr = {}
        for terbank, stats in terbank_stats.items():
            if stats['total_requests'] > 0:
                # Делим общие трудозатраты на количество заявок по этой услуге в тербанке
                avg_minutes = stats['total_minutes'] / stats['total_requests']
                avg_hours = avg_minutes / 60
                terbank_ktr[terbank] = round(avg_hours, 2)
            else:
                terbank_ktr[terbank] = 0
        # Сортируем по убыванию КТР
        return dict(sorted(terbank_ktr.items(), key=lambda x: x[1], reverse=True))

    def go_back(self):
        self.parent_ref.show_service_stats()


class WorkloadStatsWidget(QWidget):
    def __init__(self, workload_stats, employee_name, parent=None):
        super().__init__(parent)
        self.workload_stats = workload_stats
        self.employee_name = employee_name
        self.parent_ref = parent
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()
        # Заголовок
        title_label = QLabel(f"⏱️ Трудозатраты по дням: {self.employee_name}")
        title_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 16px;
            font-weight: bold;
            padding: 12px;
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #3498DB, stop:1 #2980B9);
            border-radius: 8px;
            color: white;
        }
        """)
        layout.addWidget(title_label)

        # Общая статистика
        total_minutes = sum(stats['total_minutes'] for stats in self.workload_stats.values())
        total_hours = total_minutes // 60
        remaining_minutes = total_minutes % 60
        stats_layout = QHBoxLayout()
        total_label = QLabel(f"🕐 Всего времени: {self.format_minutes(total_minutes)}")
        total_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 12px;
            padding: 10px;
            background-color: #EAFAF1;
            border-radius: 6px;
            font-weight: bold;
            border: 2px solid #27AE60;
        }
        """)
        days_label = QLabel(f"📅 Рабочих дней: {len(self.workload_stats)}")
        days_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 12px;
            padding: 10px;
            background-color: #EBF5FB;
            border-radius: 6px;
            font-weight: bold;
            border: 2px solid #3498DB;
        }
        """)
        stats_layout.addWidget(total_label)
        stats_layout.addWidget(days_label)
        stats_layout.addStretch()
        layout.addLayout(stats_layout)

        # Таблица с трудозатратами по дням
        self.workload_table = QTableWidget()
        self.workload_table.setColumnCount(4)
        self.workload_table.setHorizontalHeaderLabels(["📅 Дата", "📊 Количество заявок", "⏱️ Минут", "🕐 Часов"])
        # Заполняем таблицу данными
        self.populate_workload_table()
        # Настройка стиля таблицы
        self.workload_table.setStyleSheet("""
        QTableWidget {
            background-color: white;
            border: 2px solid #3498DB;
            border-radius: 8px;
            gridline-color: #D6EAF8;
            color: #2C3E50;
        }
        QTableWidget::item {
            padding: 8px;
            border-bottom: 1px solid #D6EAF8;
            color: #2C3E50;
        }
        QTableWidget::item:selected {
            background-color: #3498DB;
            color: white;
        }
        QHeaderView::section {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #2980B9, stop:1 #2471A3);
            color: white;
            font-weight: bold;
            padding: 10px;
            border: none;
        }
        """)
        self.workload_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(self.workload_table)

        # Кнопка назад
        back_btn = QPushButton("⬅️ Назад")
        back_btn.setStyleSheet("""
        QPushButton {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #E74C3C, stop:1 #C0392B);
            color: white;
            border: none;
            border-radius: 6px;
            padding: 12px;
            font-size: 14px;
            font-weight: bold;
        }
        QPushButton:hover {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #C0392B, stop:1 #A93226);
        }
        QPushButton:pressed {
            background: #922B21;
        }
        """)
        back_btn.clicked.connect(self.go_back)
        layout.addWidget(back_btn)
        self.setLayout(layout)

    def format_minutes(self, minutes):
        """Форматирование минут в читаемый вид"""
        clean_minutes = round(minutes, 1)
        hours = clean_minutes // 60
        mins = clean_minutes % 60
        if hours == 0:
            return f"{clean_minutes} мин."
        else:
            return f"{clean_minutes} мин. ({int(hours)} ч. {int(mins)} мин.)"

    def populate_workload_table(self):
        workload_data = []
        # Собираем все данные
        for date, stats in sorted(self.workload_stats.items(),
                                  key=lambda x: datetime.strptime(x[0], '%d.%m.%Y'),
                                  reverse=True):
            total_minutes = stats['total_minutes']
            clean_minutes = round(total_minutes, 1)
            hours = clean_minutes // 60
            minutes = clean_minutes % 60
            workload_data.append({
                'date': date,
                'requests_count': stats['requests_count'],
                'minutes': clean_minutes,
                'hours': f"{int(hours)} ч. {int(minutes)} мин."
            })
        self.workload_table.setRowCount(len(workload_data))
        for row, item in enumerate(workload_data):
            self.workload_table.setItem(row, 0, QTableWidgetItem(item['date']))
            self.workload_table.setItem(row, 1, QTableWidgetItem(str(item['requests_count'])))
            self.workload_table.setItem(row, 2, QTableWidgetItem(str(item['minutes'])))
            self.workload_table.setItem(row, 3, QTableWidgetItem(item['hours']))

    def go_back(self):
        self.parent_ref.show_employee_details(self.employee_name)


class AddressStatsWidget(QWidget):
    def __init__(self, address_stats, employee_name, parent=None):
        super().__init__(parent)
        self.address_stats = address_stats
        self.employee_name = employee_name
        self.parent_ref = parent
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()
        # Заголовок
        title_label = QLabel(f"📍 Краткое описание работ сотрудника: {self.employee_name}")
        title_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 16px;
            font-weight: bold;
            padding: 12px;
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #3498DB, stop:1 #2980B9);
            border-radius: 8px;
            color: white;
        }
        """)
        layout.addWidget(title_label)

        # Общая статистика
        total_requests = sum(sum(date_stats.values()) for date_stats in self.address_stats.values())
        total_dates = len(self.address_stats)
        stats_layout = QHBoxLayout()
        total_label = QLabel(f"📨 Всего заявок: {total_requests}")
        total_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 12px;
            padding: 10px;
            background-color: #EAFAF1;
            border-radius: 6px;
            font-weight: bold;
            border: 2px solid #27AE60;
        }
        """)
        dates_label = QLabel(f"📅 Рабочих дней: {total_dates}")
        dates_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 12px;
            padding: 10px;
            background-color: #EBF5FB;
            border-radius: 6px;
            font-weight: bold;
            border: 2px solid #3498DB;
        }
        """)
        stats_layout.addWidget(total_label)
        stats_layout.addWidget(dates_label)
        stats_layout.addStretch()
        layout.addLayout(stats_layout)

        # Таблица с адресами
        self.address_table = QTableWidget()
        self.address_table.setColumnCount(3)
        self.address_table.setHorizontalHeaderLabels(["📅 Дата", "📍 Адрес", "📊 Количество запросов"])
        # Заполняем таблицу данными
        self.populate_address_table()
        # Настройка стиля таблицы
        self.address_table.setStyleSheet("""
        QTableWidget {
            background-color: white;
            border: 2px solid #3498DB;
            border-radius: 8px;
            gridline-color: #D6EAF8;
            color: #2C3E50;
        }
        QTableWidget::item {
            padding: 8px;
            border-bottom: 1px solid #D6EAF8;
            color: #2C3E50;
        }
        QTableWidget::item:selected {
            background-color: #3498DB;
            color: white;
        }
        QHeaderView::section {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #2980B9, stop:1 #2471A3);
            color: white;
            font-weight: bold;
            padding: 10px;
            border: none;
        }
        """)
        self.address_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(self.address_table)

        # Кнопка назад
        back_btn = QPushButton("⬅️ Назад")
        back_btn.setStyleSheet("""
        QPushButton {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #E74C3C, stop:1 #C0392B);
            color: white;
            border: none;
            border-radius: 6px;
            padding: 12px;
            font-size: 14px;
            font-weight: bold;
        }
        QPushButton:hover {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #C0392B, stop:1 #A93226);
        }
        QPushButton:pressed {
            background: #922B21;
        }
        """)
        back_btn.clicked.connect(self.go_back)
        layout.addWidget(back_btn)
        self.setLayout(layout)

    def populate_address_table(self):
        address_data = []
        # Собираем все данные
        for date, addresses in sorted(self.address_stats.items(),
                                      key=lambda x: datetime.strptime(x[0], '%d.%m.%Y'),
                                      reverse=True):
            # Сортируем адреса по количеству запросов (убывание)
            sorted_addresses = sorted(addresses.items(), key=lambda x: x[1], reverse=True)
            for address, count in sorted_addresses:
                address_data.append({
                    'date': date,
                    'address': address,
                    'count': count
                })
        self.address_table.setRowCount(len(address_data))
        for row, item in enumerate(address_data):
            self.address_table.setItem(row, 0, QTableWidgetItem(item['date']))
            self.address_table.setItem(row, 1, QTableWidgetItem(item['address']))
            self.address_table.setItem(row, 2, QTableWidgetItem(str(item['count'])))

    def go_back(self):
        self.parent_ref.show_employee_details(self.employee_name)


class CodeDetailWidget(QWidget):
    def __init__(self, code_data, parent=None):
        super().__init__(parent)
        self.code_data = code_data
        self.parent_ref = parent
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()
        # Заголовок
        title_label = QLabel(f"🔍 Детальная информация по коду: {self.code_data['code']}")
        title_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 16px;
            font-weight: bold;
            padding: 12px;
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #3498DB, stop:1 #2980B9);
            border-radius: 8px;
            color: white;
        }
        """)
        layout.addWidget(title_label)

        # Информация о сотруднике и количестве
        info_layout = QHBoxLayout()
        employee_label = QLabel(f"👤 Сотрудник: {self.code_data['employee']}")
        employee_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 12px;
            font-weight: bold;
            padding: 10px;
            background-color: #EBF5FB;
            border-radius: 6px;
            border: 2px solid #3498DB;
        }
        """)
        count_label = QLabel(f"📊 Всего заявок: {len(self.code_data['requests'])}")
        count_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 12px;
            font-weight: bold;
            padding: 10px;
            background-color: #EAFAF1;
            border-radius: 6px;
            border: 2px solid #27AE60;
        }
        """)
        info_layout.addWidget(employee_label)
        info_layout.addWidget(count_label)
        info_layout.addStretch()
        layout.addLayout(info_layout)

        # Описание работы из КТР
        if 'work_description' in self.code_data and self.code_data['work_description']:
            description_layout = QVBoxLayout()
            description_label = QLabel(f"📝 Описание работы: {self.code_data['work_description']}")
            description_label.setStyleSheet("""
            QLabel {
                color: #2C3E50;
                font-size: 12px;
                padding: 10px;
                background-color: #FEF9E7;
                border-radius: 6px;
                border-left: 4px solid #F39C12;
                border: 2px solid #F39C12;
            }
            """)
            description_label.setWordWrap(True)
            description_layout.addWidget(description_label)
            layout.addLayout(description_layout)

        # Таблица с детальной информацией по заявкам
        self.detail_table = QTableWidget()
        self.detail_table.setColumnCount(6)
        self.detail_table.setHorizontalHeaderLabels(["📋 Запрос", "📍 Размещение", "📅 Регистрация", "✅ Закрытие", "🏁 Окончание работ", "🔑 Код ARM"])
        # Заполняем таблицу данными
        self.populate_detail_table()
        # Настройка стиля таблицы
        self.detail_table.setStyleSheet("""
        QTableWidget {
            background-color: white;
            border: 2px solid #3498DB;
            border-radius: 8px;
            gridline-color: #D6EAF8;
            color: #2C3E50;
        }
        QTableWidget::item {
            padding: 8px;
            border-bottom: 1px solid #D6EAF8;
            color: #2C3E50;
        }
        QTableWidget::item:selected {
            background-color: #3498DB;
            color: white;
        }
        QHeaderView::section {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #2980B9, stop:1 #2471A3);
            color: white;
            font-weight: bold;
            padding: 10px;
            border: none;
        }
        """)
        self.detail_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(self.detail_table)

        # Кнопка назад
        back_btn = QPushButton("⬅️ Назад")
        back_btn.setStyleSheet("""
        QPushButton {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #E74C3C, stop:1 #C0392B);
            color: white;
            border: none;
            border-radius: 6px;
            padding: 12px;
            font-size: 14px;
            font-weight: bold;
        }
        QPushButton:hover {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #C0392B, stop:1 #A93226);
        }
        QPushButton:pressed {
            background: #922B21;
        }
        """)
        back_btn.clicked.connect(self.go_back)
        layout.addWidget(back_btn)
        self.setLayout(layout)

    def populate_detail_table(self):
        self.detail_table.setRowCount(len(self.code_data['requests']))
        for row, request in enumerate(self.code_data['requests']):
            # Номер заявки
            self.detail_table.setItem(row, 0, QTableWidgetItem(str(request.get('request_number', ''))))
            # Размещение
            self.detail_table.setItem(row, 1, QTableWidgetItem(str(request.get('placement', ''))))
            # Дата регистрации
            self.detail_table.setItem(row, 2, QTableWidgetItem(str(request.get('registration_date', ''))))
            # Дата закрытия
            self.detail_table.setItem(row, 3, QTableWidgetItem(str(request.get('closing_date', ''))))
            # Дата окончания работ
            self.detail_table.setItem(row, 4, QTableWidgetItem(str(request.get('completion_date', ''))))
            # Код ARM
            self.detail_table.setItem(row, 5, QTableWidgetItem(self.code_data['code']))

    def go_back(self):
        self.parent_ref.show_employee_details(self.code_data['employee'])


class Top20Widget(QWidget):
    def __init__(self, top_employees, parent=None):
        super().__init__(parent)
        self.top_employees = top_employees
        self.parent_ref = parent
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()
        # Заголовок
        title_label = QLabel("🏆 ТОП-20 сотрудников по производительности")
        title_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 18px;
            font-weight: bold;
            padding: 15px;
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #F39C12, stop:1 #E67E22);
            border-radius: 10px;
            text-align: center;
            color: white;
        }
        """)
        layout.addWidget(title_label)

        # Информация о количестве сотрудников
        count_label = QLabel(f"👥 Всего в топе: {len(self.top_employees)} сотрудников")
        count_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 14px;
            font-weight: bold;
            padding: 10px;
            background-color: #FEF9E7;
            border-radius: 6px;
            border: 2px solid #F39C12;
        }
        """)
        layout.addWidget(count_label)

        # Таблица ТОП-20
        self.top_table = QTableWidget()
        self.top_table.setColumnCount(4)
        self.top_table.setHorizontalHeaderLabels(["🏅 Место", "👤 Сотрудник", "🏢 Тербанк", "📊 Заявок"])
        # Заполняем таблицу
        self.populate_top_table()
        # Стиль таблицы
        self.top_table.setStyleSheet("""
        QTableWidget {
            background-color: white;
            border: 2px solid #F39C12;
            border-radius: 8px;
            gridline-color: #FBEEE6;
            font-size: 12px;
        }
        QTableWidget::item {
            padding: 10px;
            border-bottom: 1px solid #FBEEE6;
            color: #2C3E50;
        }
        QTableWidget::item:selected {
            background-color: #F39C12;
            color: white;
        }
        QHeaderView::section {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #E67E22, stop:1 #D35400);
            color: white;
            font-weight: bold;
            padding: 12px;
            border: none;
            font-size: 13px;
        }
        """)
        self.top_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.top_table.cellDoubleClicked.connect(self.on_employee_double_click)
        layout.addWidget(self.top_table)

        # Кнопка назад
        back_btn = QPushButton("⬅️ Назад")
        back_btn.setStyleSheet("""
        QPushButton {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #E74C3C, stop:1 #C0392B);
            color: white;
            border: none;
            border-radius: 6px;
            padding: 12px;
            font-size: 14px;
            font-weight: bold;
        }
        QPushButton:hover {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #C0392B, stop:1 #A93226);
        }
        QPushButton:pressed {
            background: #922B21;
        }
        """)
        back_btn.clicked.connect(self.go_back)
        layout.addWidget(back_btn)
        self.setLayout(layout)

    def populate_top_table(self):
        self.top_table.setRowCount(len(self.top_employees))
        for row, (fio, data) in enumerate(self.top_employees):
            # Место
            place_item = QTableWidgetItem()
            if row == 0:
                place_item.setText("🥇 1")
                place_item.setBackground(QColor(255, 215, 0))  # Золотой
            elif row == 1:
                place_item.setText("🥈 2")
                place_item.setBackground(QColor(192, 192, 192))  # Серебряный
            elif row == 2:
                place_item.setText("🥉 3")
                place_item.setBackground(QColor(205, 127, 50))  # Бронзовый
            else:
                place_item.setText(f"{row + 1}")
            place_item.setFlags(place_item.flags() & ~Qt.ItemIsEditable)
            self.top_table.setItem(row, 0, place_item)
            # ФИО
            name_item = QTableWidgetItem(fio)
            name_item.setFlags(name_item.flags() & ~Qt.ItemIsEditable)
            self.top_table.setItem(row, 1, name_item)
            # Тербанк
            terbank_item = QTableWidgetItem(data['terbank'])
            terbank_item.setFlags(terbank_item.flags() & ~Qt.ItemIsEditable)
            self.top_table.setItem(row, 2, terbank_item)
            # Количество заявок
            count_item = QTableWidgetItem(str(data['total_requests']))
            count_item.setFlags(count_item.flags() & ~Qt.ItemIsEditable)
            self.top_table.setItem(row, 3, count_item)

    def on_employee_double_click(self, row, column):
        """Обработка двойного клика по сотруднику"""
        fio = self.top_table.item(row, 1).text()
        self.parent_ref.show_employee_details(fio)

    def go_back(self):
        self.parent_ref.show_main_screen()


class Top20EfficiencyWidget(QWidget):
    def __init__(self, top_employees, parent=None):
        super().__init__(parent)
        self.top_employees = top_employees
        self.parent_ref = parent
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()
        # Заголовок
        title_label = QLabel("⚡ ТОП-20 сотрудников по эффективности (трудозатраты/день)")
        title_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 18px;
            font-weight: bold;
            padding: 15px;
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #9B59B6, stop:1 #8E44AD);
            border-radius: 10px;
            text-align: center;
            color: white;
        }
        """)
        layout.addWidget(title_label)

        # Информация о количестве сотрудников
        count_label = QLabel(f"👥 Всего в топе: {len(self.top_employees)} сотрудников")
        count_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 14px;
            font-weight: bold;
            padding: 10px;
            background-color: #F4ECF7;
            border-radius: 6px;
            border: 2px solid #9B59B6;
        }
        """)
        layout.addWidget(count_label)

        # Таблица ТОП-20 по эффективности
        self.top_table = QTableWidget()
        self.top_table.setColumnCount(6)
        self.top_table.setHorizontalHeaderLabels(["🏅 Место", "👤 Сотрудник", "🏢 Тербанк", "⏱️ Трудозатраты", "📅 Дней", "📈 Эффективность"])
        # Заполняем таблицу
        self.populate_top_table()
        # Стиль таблицы
        self.top_table.setStyleSheet("""
        QTableWidget {
            background-color: white;
            border: 2px solid #9B59B6;
            border-radius: 8px;
            gridline-color: #F4ECF7;
            font-size: 12px;
        }
        QTableWidget::item {
            padding: 10px;
            border-bottom: 1px solid #F4ECF7;
            color: #2C3E50;
        }
        QTableWidget::item:selected {
            background-color: #9B59B6;
            color: white;
        }
        QHeaderView::section {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #8E44AD, stop:1 #7D3C98);
            color: white;
            font-weight: bold;
            padding: 12px;
            border: none;
            font-size: 13px;
        }
        """)
        self.top_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.top_table.cellDoubleClicked.connect(self.on_employee_double_click)
        layout.addWidget(self.top_table)

        # Кнопка назад
        back_btn = QPushButton("⬅️ Назад")
        back_btn.setStyleSheet("""
        QPushButton {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #E74C3C, stop:1 #C0392B);
            color: white;
            border: none;
            border-radius: 6px;
            padding: 12px;
            font-size: 14px;
            font-weight: bold;
        }
        QPushButton:hover {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #C0392B, stop:1 #A93226);
        }
        QPushButton:pressed {
            background: #922B21;
        }
        """)
        back_btn.clicked.connect(self.go_back)
        layout.addWidget(back_btn)
        self.setLayout(layout)

    def populate_top_table(self):
        self.top_table.setRowCount(len(self.top_employees))
        for row, (fio, data) in enumerate(self.top_employees):
            # Место
            place_item = QTableWidgetItem()
            if row == 0:
                place_item.setText("🥇 1")
                place_item.setBackground(QColor(255, 215, 0))  # Золотой
            elif row == 1:
                place_item.setText("🥈 2")
                place_item.setBackground(QColor(192, 192, 192))  # Серебряный
            elif row == 2:
                place_item.setText("🥉 3")
                place_item.setBackground(QColor(205, 127, 50))  # Бронзовый
            else:
                place_item.setText(f"{row + 1}")
            place_item.setFlags(place_item.flags() & ~Qt.ItemIsEditable)
            self.top_table.setItem(row, 0, place_item)
            # ФИО
            name_item = QTableWidgetItem(fio)
            name_item.setFlags(name_item.flags() & ~Qt.ItemIsEditable)
            self.top_table.setItem(row, 1, name_item)
            # Тербанк
            terbank_item = QTableWidgetItem(data['terbank'])
            terbank_item.setFlags(terbank_item.flags() & ~Qt.ItemIsEditable)
            self.top_table.setItem(row, 2, terbank_item)
            # Трудозатраты
            workload_item = QTableWidgetItem(f"{data['total_minutes']:.1f} мин.")
            workload_item.setFlags(workload_item.flags() & ~Qt.ItemIsEditable)
            self.top_table.setItem(row, 3, workload_item)
            # Дней
            days_item = QTableWidgetItem(str(data['work_days']))
            days_item.setFlags(days_item.flags() & ~Qt.ItemIsEditable)
            self.top_table.setItem(row, 4, days_item)
            # Эффективность (трудозатраты в день)
            efficiency = data['total_minutes'] / data['work_days'] if data['work_days'] > 0 else 0
            efficiency_item = QTableWidgetItem(f"{efficiency:.1f} мин./день")
            efficiency_item.setFlags(efficiency_item.flags() & ~Qt.ItemIsEditable)
            self.top_table.setItem(row, 5, efficiency_item)

    def on_employee_double_click(self, row, column):
        """Обработка двойного клика по сотруднику"""
        fio = self.top_table.item(row, 1).text()
        self.parent_ref.show_employee_details(fio)

    def go_back(self):
        self.parent_ref.show_main_screen()


class AllRequestsWidget(QWidget):
    def __init__(self, requests_data, title, parent=None):
        super().__init__(parent)
        self.requests_data = requests_data
        self.title = title
        self.parent_ref = parent
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()
        # Заголовок
        title_label = QLabel(self.title)
        title_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 16px;
            font-weight: bold;
            padding: 12px;
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #3498DB, stop:1 #2980B9);
            border-radius: 8px;
            color: white;
        }
        """)
        layout.addWidget(title_label)

        # Общая статистика
        total_requests = len(self.requests_data)
        stats_layout = QHBoxLayout()
        total_label = QLabel(f"📊 Всего заявок: {total_requests}")
        total_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 12px;
            padding: 10px;
            background-color: #EAFAF1;
            border-radius: 6px;
            font-weight: bold;
            border: 2px solid #27AE60;
        }
        """)
        stats_layout.addWidget(total_label)
        stats_layout.addStretch()
        layout.addLayout(stats_layout)

        # Кнопка выгрузки
        export_btn = QPushButton("📥 Выгрузить в Excel")
        export_btn.setStyleSheet("""
        QPushButton {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #27AE60, stop:1 #229954);
            color: white;
            border: none;
            border-radius: 6px;
            padding: 12px;
            font-size: 14px;
            font-weight: bold;
        }
        QPushButton:hover {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #229954, stop:1 #1E8449);
        }
        QPushButton:pressed {
            background: #196F3D;
        }
        """)
        export_btn.clicked.connect(self.export_to_excel)
        layout.addWidget(export_btn)

        # Таблица с заявками
        self.requests_table = QTableWidget()
        # Заполняем таблицу данными
        self.populate_requests_table()
        # Настройка стиля таблицы
        self.requests_table.setStyleSheet("""
        QTableWidget {
            background-color: white;
            border: 2px solid #3498DB;
            border-radius: 8px;
            gridline-color: #D6EAF8;
            color: #2C3E50;
            font-size: 10px;
        }
        QTableWidget::item {
            padding: 6px;
            border-bottom: 1px solid #D6EAF8;
            color: #2C3E50;
        }
        QTableWidget::item:selected {
            background-color: #3498DB;
            color: white;
        }
        QHeaderView::section {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #2980B9, stop:1 #2471A3);
            color: white;
            font-weight: bold;
            padding: 8px;
            border: none;
            font-size: 10px;
        }
        """)
        self.requests_table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        layout.addWidget(self.requests_table)

        # Кнопка назад
        back_btn = QPushButton("⬅️ Назад")
        back_btn.setStyleSheet("""
        QPushButton {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #E74C3C, stop:1 #C0392B);
            color: white;
            border: none;
            border-radius: 6px;
            padding: 12px;
            font-size: 14px;
            font-weight: bold;
        }
        QPushButton:hover {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #C0392B, stop:1 #A93226);
        }
        QPushButton:pressed {
            background: #922B21;
        }
        """)
        back_btn.clicked.connect(self.go_back)
        layout.addWidget(back_btn)
        self.setLayout(layout)

    def populate_requests_table(self):
        if not self.requests_data:
            return
        # Используем все колонки из исходных данных
        columns = list(self.requests_data[0].keys())
        self.requests_table.setColumnCount(len(columns))
        self.requests_table.setHorizontalHeaderLabels(columns)
        self.requests_table.setRowCount(len(self.requests_data))
        for row, request in enumerate(self.requests_data):
            for col, column_name in enumerate(columns):
                value = request.get(column_name, '')
                item = QTableWidgetItem(str(value))
                item.setToolTip(str(value))
                self.requests_table.setItem(row, col, item)
        # Настраиваем ширину колонок
        header = self.requests_table.horizontalHeader()
        for i in range(len(columns)):
            header.setSectionResizeMode(i, QHeaderView.ResizeToContents)

    def export_to_excel(self):
        """Экспорт данных в Excel файл"""
        if not self.requests_data:
            QMessageBox.warning(self, "Внимание", "Нет данных для экспорта")
            return
        file_path, _ = QFileDialog.getSaveFileName(
            self,
            "Сохранить как Excel",
            f"{self.title.replace(' ', '_')}.xlsx",
            "Excel Files (*.xlsx);;All Files (*)"
        )
        if file_path:
            try:
                # Создаем DataFrame из данных
                df = pd.DataFrame(self.requests_data)
                df.to_excel(file_path, index=False)
                QMessageBox.information(self, "Успех", f"Данные успешно экспортированы в {file_path}")
            except Exception as e:
                QMessageBox.critical(self, "Ошибка", f"Ошибка при экспорте: {str(e)}")

    def go_back(self):
        self.parent_ref.show_previous_screen()


class EmployeeRequestsWidget(QWidget):
    def __init__(self, requests_data, employee_name, parent=None):
        super().__init__(parent)
        self.requests_data = requests_data
        self.employee_name = employee_name
        self.parent_ref = parent
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()
        # Заголовок
        title_label = QLabel(f"📋 Все заявки сотрудника: {self.employee_name}")
        title_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 16px;
            font-weight: bold;
            padding: 12px;
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #3498DB, stop:1 #2980B9);
            border-radius: 8px;
            color: white;
        }
        """)
        layout.addWidget(title_label)

        # Общая статистика
        total_requests = len(self.requests_data)
        stats_layout = QHBoxLayout()
        total_label = QLabel(f"📊 Всего заявок: {total_requests}")
        total_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 12px;
            padding: 10px;
            background-color: #EAFAF1;
            border-radius: 6px;
            font-weight: bold;
            border: 2px solid #27AE60;
        }
        """)
        stats_layout.addWidget(total_label)
        stats_layout.addStretch()
        layout.addLayout(stats_layout)

        # Кнопка выгрузки
        export_btn = QPushButton("📥 Выгрузить в Excel")
        export_btn.setStyleSheet("""
        QPushButton {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #27AE60, stop:1 #229954);
            color: white;
            border: none;
            border-radius: 6px;
            padding: 12px;
            font-size: 14px;
            font-weight: bold;
        }
        QPushButton:hover {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #229954, stop:1 #1E8449);
        }
        QPushButton:pressed {
            background: #196F3D;
        }
        """)
        export_btn.clicked.connect(self.export_to_excel)
        layout.addWidget(export_btn)

        # Таблица с заявками
        self.requests_table = QTableWidget()
        # Заполняем таблицу данными
        self.populate_requests_table()
        # Настройка стиля таблицы
        self.requests_table.setStyleSheet("""
        QTableWidget {
            background-color: white;
            border: 2px solid #3498DB;
            border-radius: 8px;
            gridline-color: #D6EAF8;
            color: #2C3E50;
            font-size: 10px;
        }
        QTableWidget::item {
            padding: 6px;
            border-bottom: 1px solid #D6EAF8;
            color: #2C3E50;
        }
        QTableWidget::item:selected {
            background-color: #3498DB;
            color: white;
        }
        QHeaderView::section {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #2980B9, stop:1 #2471A3);
            color: white;
            font-weight: bold;
            padding: 8px;
            border: none;
            font-size: 10px;
        }
        """)
        self.requests_table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        layout.addWidget(self.requests_table)

        # Кнопка назад
        back_btn = QPushButton("⬅️ Назад")
        back_btn.setStyleSheet("""
        QPushButton {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #E74C3C, stop:1 #C0392B);
            color: white;
            border: none;
            border-radius: 6px;
            padding: 12px;
            font-size: 14px;
            font-weight: bold;
        }
        QPushButton:hover {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #C0392B, stop:1 #A93226);
        }
        QPushButton:pressed {
            background: #922B21;
        }
        """)
        back_btn.clicked.connect(self.go_back)
        layout.addWidget(back_btn)
        self.setLayout(layout)

    def populate_requests_table(self):
        if not self.requests_data:
            return
        # Используем все колонки из исходных данных
        columns = list(self.requests_data[0].keys())
        self.requests_table.setColumnCount(len(columns))
        self.requests_table.setHorizontalHeaderLabels(columns)
        self.requests_table.setRowCount(len(self.requests_data))
        for row, request in enumerate(self.requests_data):
            for col, column_name in enumerate(columns):
                value = request.get(column_name, '')
                item = QTableWidgetItem(str(value))
                item.setToolTip(str(value))
                self.requests_table.setItem(row, col, item)
        # Настраиваем ширину колонок
        header = self.requests_table.horizontalHeader()
        for i in range(len(columns)):
            header.setSectionResizeMode(i, QHeaderView.ResizeToContents)

    def export_to_excel(self):
        """Экспорт данных в Excel файл"""
        if not self.requests_data:
            QMessageBox.warning(self, "Внимание", "Нет данных для экспорта")
            return
        file_path, _ = QFileDialog.getSaveFileName(
            self,
            "Сохранить как Excel",
            f"Заявки_сотрудника_{self.employee_name}.xlsx",
            "Excel Files (*.xlsx);;All Files (*)"
        )
        if file_path:
            try:
                # Создаем DataFrame из данных
                df = pd.DataFrame(self.requests_data)
                df.to_excel(file_path, index=False)
                QMessageBox.information(self, "Успех", f"Данные успешно экспортированы в {file_path}")
            except Exception as e:
                QMessageBox.critical(self, "Ошибка", f"Ошибка при экспорте: {str(e)}")

    def go_back(self):
        self.parent_ref.show_employee_details(self.employee_name)


class SuspiciousRequestsWidget(QWidget):
    def __init__(self, requests_data, case_info, parent=None):
        super().__init__(parent)
        self.requests_data = requests_data
        self.case_info = case_info
        self.parent_ref = parent
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()
        # Заголовок
        title_label = QLabel(f"🚨 Подозрительные заявки: {self.case_info['employee']}")
        title_label.setStyleSheet("""
        QLabel {
            color: #FFFFFF;
            font-size: 16px;
            font-weight: bold;
            padding: 12px;
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #E74C3C, stop:1 #C0392B);
            border-radius: 8px;
        }
        """)
        layout.addWidget(title_label)

        # Информация о случае
        info_layout = QVBoxLayout()
        address_label = QLabel(f"📍 Адрес: {self.case_info['address']}")
        address_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 12px;
            font-weight: bold;
            padding: 8px;
            background-color: #EBF5FB;
            border-radius: 6px;
            border: 2px solid #3498DB;
        }
        """)
        date_label = QLabel(f"📅 Дата: {self.case_info['date']}")
        date_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 12px;
            font-weight: bold;
            padding: 8px;
            background-color: #EAFAF1;
            border-radius: 6px;
            border: 2px solid #27AE60;
        }
        """)
        time_label = QLabel(f"⏰ Временной интервал: {self.case_info['first_visit_time']} - {self.case_info['new_requests_time']}")
        time_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 12px;
            font-weight: bold;
            padding: 8px;
            background-color: #FEF9E7;
            border-radius: 6px;
            border: 2px solid #F39C12;
        }
        """)
        info_layout.addWidget(address_label)
        info_layout.addWidget(date_label)
        info_layout.addWidget(time_label)
        layout.addLayout(info_layout)

        # Общая статистика
        total_requests = len(self.requests_data)
        stats_layout = QHBoxLayout()
        total_label = QLabel(f"🚩 Всего подозрительных заявок: {total_requests}")
        total_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 12px;
            padding: 10px;
            background-color: #FDEDEC;
            border-radius: 6px;
            font-weight: bold;
            border: 2px solid #E74C3C;
        }
        """)
        stats_layout.addWidget(total_label)
        stats_layout.addStretch()
        layout.addLayout(stats_layout)

        # Кнопка выгрузки
        export_btn = QPushButton("📥 Выгрузить в Excel")
        export_btn.setStyleSheet("""
        QPushButton {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #27AE60, stop:1 #229954);
            color: white;
            border: none;
            border-radius: 6px;
            padding: 12px;
            font-size: 14px;
            font-weight: bold;
        }
        QPushButton:hover {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #229954, stop:1 #1E8449);
        }
        QPushButton:pressed {
            background: #196F3D;
        }
        """)
        export_btn.clicked.connect(self.export_to_excel)
        layout.addWidget(export_btn)

        # Таблица с заявками
        self.requests_table = QTableWidget()
        # Заполняем таблицу данными
        self.populate_requests_table()
        # Настройка стиля таблицы
        self.requests_table.setStyleSheet("""
        QTableWidget {
            background-color: white;
            border: 2px solid #E74C3C;
            border-radius: 8px;
            gridline-color: #FDEDEC;
            color: #2C3E50;
            font-size: 10px;
        }
        QTableWidget::item {
            padding: 6px;
            border-bottom: 1px solid #FDEDEC;
            color: #2C3E50;
        }
        QTableWidget::item:selected {
            background-color: #E74C3C;
            color: white;
        }
        QHeaderView::section {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #C0392B, stop:1 #A93226);
            color: white;
            font-weight: bold;
            padding: 8px;
            border: none;
            font-size: 10px;
        }
        """)
        self.requests_table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        layout.addWidget(self.requests_table)

        # Кнопка назад
        back_btn = QPushButton("⬅️ Назад")
        back_btn.setStyleSheet("""
        QPushButton {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #E74C3C, stop:1 #C0392B);
            color: white;
            border: none;
            border-radius: 6px;
            padding: 12px;
            font-size: 14px;
            font-weight: bold;
        }
        QPushButton:hover {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #C0392B, stop:1 #A93226);
        }
        QPushButton:pressed {
            background: #922B21;
        }
        """)
        back_btn.clicked.connect(self.go_back)
        layout.addWidget(back_btn)
        self.setLayout(layout)

    def populate_requests_table(self):
        if not self.requests_data:
            return
        # Используем все колонки из исходных данных
        columns = list(self.requests_data[0].keys())
        self.requests_table.setColumnCount(len(columns))
        self.requests_table.setHorizontalHeaderLabels(columns)
        self.requests_table.setRowCount(len(self.requests_data))
        for row, request in enumerate(self.requests_data):
            for col, column_name in enumerate(columns):
                value = request.get(column_name, '')
                item = QTableWidgetItem(str(value))
                item.setToolTip(str(value))
                self.requests_table.setItem(row, col, item)
        # Настраиваем ширину колонок
        header = self.requests_table.horizontalHeader()
        for i in range(len(columns)):
            header.setSectionResizeMode(i, QHeaderView.ResizeToContents)

    def export_to_excel(self):
        """Экспорт данных в Excel файл"""
        if not self.requests_data:
            QMessageBox.warning(self, "Внимание", "Нет данных для экспорта")
            return
        file_path, _ = QFileDialog.getSaveFileName(
            self,
            "Сохранить как Excel",
            f"Подозрительные_заявки_{self.case_info['employee']}.xlsx",
            "Excel Files (*.xlsx);;All Files (*)"
        )
        if file_path:
            try:
                # Создаем DataFrame из данных
                df = pd.DataFrame(self.requests_data)
                df.to_excel(file_path, index=False)
                QMessageBox.information(self, "Успех", f"Данные успешно экспортированы в {file_path}")
            except Exception as e:
                QMessageBox.critical(self, "Ошибка", f"Ошибка при экспорте: {str(e)}")

    def go_back(self):
        self.parent_ref.show_suspicious_activity()


class EmployeeDetailWidget(QWidget):
    def __init__(self, employee_data, parent=None):
        super().__init__(parent)
        self.employee_data = employee_data
        self.parent_ref = parent
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()
        # Заголовок
        title_label = QLabel(f"👤 Детальная статистика по сотруднику: {self.employee_data['fio']}")
        title_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 16px;
            font-weight: bold;
            padding: 12px;
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #3498DB, stop:1 #2980B9);
            border-radius: 8px;
            color: white;
        }
        """)
        layout.addWidget(title_label)

        # Информация о тербанке и периоде
        info_layout = QHBoxLayout()
        terbank_label = QLabel(f"🏢 Тербанк: {self.employee_data.get('terbank', 'Не указан')}")
        terbank_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 12px;
            font-weight: bold;
            padding: 10px;
            background-color: #EBF5FB;
            border-radius: 6px;
            border: 2px solid #3498DB;
        }
        """)
        period_label = QLabel(f"📅 Период: {self.employee_data['period']}")
        period_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 12px;
            font-weight: bold;
            padding: 10px;
            background-color: #EAFAF1;
            border-radius: 6px;
            border: 2px solid #27AE60;
        }
        """)
        info_layout.addWidget(terbank_label)
        info_layout.addWidget(period_label)
        layout.addLayout(info_layout)

        # Кнопка краткого описания работ
        address_stats_btn = QPushButton("📍 Краткое описание работ")
        address_stats_btn.setStyleSheet("""
        QPushButton {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #3498DB, stop:1 #2980B9);
            color: white;
            border: none;
            border-radius: 6px;
            padding: 12px;
            font-size: 14px;
            font-weight: bold;
        }
        QPushButton:hover {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #2980B9, stop:1 #2471A3);
        }
        QPushButton:pressed {
            background: #1F618D;
        }
        """)
        address_stats_btn.clicked.connect(self.show_address_stats)
        layout.addWidget(address_stats_btn)

        # Кнопка всех заявок сотрудника
        all_requests_btn = QPushButton("📋 Все заявки сотрудника")
        all_requests_btn.setStyleSheet("""
        QPushButton {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #9B59B6, stop:1 #8E44AD);
            color: white;
            border: none;
            border-radius: 6px;
            padding: 12px;
            font-size: 14px;
            font-weight: bold;
        }
        QPushButton:hover {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #8E44AD, stop:1 #7D3C98);
        }
        QPushButton:pressed {
            background: #6C3483;
        }
        """)
        all_requests_btn.clicked.connect(self.show_all_requests)
        layout.addWidget(all_requests_btn)

        # Общая статистика
        stats_layout = QHBoxLayout()
        total_requests_label = QLabel(f"📨 Всего заявок: {self.employee_data['total_requests']}")
        total_requests_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 12px;
            padding: 8px;
            background-color: #EAFAF1;
            border-radius: 6px;
            border: 2px solid #27AE60;
        }
        """)
        # Делаем метку кликабельной
        total_requests_label.mouseDoubleClickEvent = lambda event: self.show_all_requests()
        total_requests_label.setCursor(Qt.PointingHandCursor)
        total_codes_label = QLabel(f"🔑 Уникальных кодов: {len(self.employee_data['arm_codes'])}")
        total_codes_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 12px;
            padding: 8px;
            background-color: #EBF5FB;
            border-radius: 6px;
            border: 2px solid #3498DB;
        }
        """)
        # Трудозатраты
        total_minutes = self.employee_data.get('total_workload_minutes', 0)
        workload_text = self.format_minutes(total_minutes)
        workload_label = QLabel(f"⏱️ Трудозатраты: {workload_text}")
        workload_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 12px;
            padding: 8px;
            background-color: #FEF9E7;
            border-radius: 6px;
            border: 2px solid #F39C12;
        }
        """)
        # Делаем метку кликабельной
        workload_label.mouseDoubleClickEvent = lambda event: self.show_workload_stats()
        workload_label.setCursor(Qt.PointingHandCursor)
        stats_layout.addWidget(total_requests_label)
        stats_layout.addWidget(total_codes_label)
        stats_layout.addWidget(workload_label)
        stats_layout.addStretch()
        layout.addLayout(stats_layout)

        # Таблица с кодами ARM и описаниями
        self.codes_table = QTableWidget()
        self.codes_table.setColumnCount(3)
        self.codes_table.setHorizontalHeaderLabels(["🔑 Код ARM", "📝 Описание работы", "📊 Количество"])
        # Заполняем таблицу данными
        self.populate_codes_table()
        # Настройка стиля таблицы
        self.codes_table.setStyleSheet("""
        QTableWidget {
            background-color: white;
            border: 2px solid #3498DB;
            border-radius: 8px;
            gridline-color: #D6EAF8;
            color: #2C3E50;
        }
        QTableWidget::item {
            padding: 8px;
            border-bottom: 1px solid #D6EAF8;
            color: #2C3E50;
        }
        QTableWidget::item:selected {
            background-color: #3498DB;
            color: white;
        }
        QHeaderView::section {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #2980B9, stop:1 #2471A3);
            color: white;
            font-weight: bold;
            padding: 10px;
            border: none;
        }
        """)
        # Настраиваем ширину колонок
        header = self.codes_table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeToContents)  # Код ARM - минимальная ширина
        header.setSectionResizeMode(1, QHeaderView.Stretch)  # Описание - растягивается
        header.setSectionResizeMode(2, QHeaderView.ResizeToContents)  # Количество - минимальная ширина
        self.codes_table.cellDoubleClicked.connect(self.on_code_double_click)
        layout.addWidget(self.codes_table)

        # Кнопка назад
        back_btn = QPushButton("⬅️ Назад")
        back_btn.setStyleSheet("""
        QPushButton {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #E74C3C, stop:1 #C0392B);
            color: white;
            border: none;
            border-radius: 6px;
            padding: 12px;
            font-size: 14px;
            font-weight: bold;
        }
        QPushButton:hover {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #C0392B, stop:1 #A93226);
        }
        QPushButton:pressed {
            background: #922B21;
        }
        """)
        back_btn.clicked.connect(self.go_back)
        layout.addWidget(back_btn)
        self.setLayout(layout)

    def format_minutes(self, minutes):
        """Форматирование минут в читаемый вид"""
        clean_minutes = round(minutes, 1)
        hours = clean_minutes // 60
        mins = clean_minutes % 60
        if hours == 0:
            return f"{clean_minutes} мин."
        else:
            return f"{clean_minutes} мин. ({int(hours)} ч. {int(mins)} мин.)"

    def populate_codes_table(self):
        """Заполняем таблицу кодами ARM, описаниями и их количеством"""
        codes_data = []
        for code, code_info in self.employee_data['arm_codes'].items():
            codes_data.append({
                'code': code,
                'description': code_info.get('description', 'Описание не найдено'),
                'count': code_info['count']
            })
        # Сортируем по количеству (убывание)
        codes_data.sort(key=lambda x: x['count'], reverse=True)
        self.codes_table.setRowCount(len(codes_data))
        for row, item in enumerate(codes_data):
            self.codes_table.setItem(row, 0, QTableWidgetItem(item['code']))
            # Описание работы
            description_item = QTableWidgetItem(item['description'])
            description_item.setToolTip(item['description'])  # Подсказка при наведении
            self.codes_table.setItem(row, 1, description_item)
            count_item = QTableWidgetItem(str(item['count']))
            count_item.setData(Qt.UserRole, {'code': item['code'], 'employee': self.employee_data['fio']})
            self.codes_table.setItem(row, 2, count_item)

    def on_code_double_click(self, row, column):
        """Обработка двойного клика по коду ARM"""
        if column == 2:  # Колонка "Количество"
            item = self.codes_table.item(row, column)
            if item and item.data(Qt.UserRole):
                code_data = item.data(Qt.UserRole)
                self.parent_ref.show_code_details(code_data['code'], code_data['employee'])
        else:
            code = self.codes_table.item(row, 0).text()
            self.parent_ref.show_code_details(code, self.employee_data['fio'])

    def show_address_stats(self):
        """Показ статистики по адресам"""
        address_stats = self.calculate_address_stats()
        self.parent_ref.show_address_stats(address_stats, self.employee_data['fio'])

    def show_all_requests(self):
        """Показ всех заявок сотрудника"""
        self.parent_ref.show_employee_requests(self.employee_data['fio'])

    def show_workload_stats(self):
        """Показ статистики по трудозатратам"""
        workload_stats = self.calculate_workload_stats()
        self.parent_ref.show_workload_stats(workload_stats, self.employee_data['fio'])

    def calculate_address_stats(self):
        """Расчет статистики по адресам"""
        address_stats = {}
        for request in self.employee_data['requests_data']:
            # Получаем дату окончания работ
            completion_date = request.get('completion_date', '')
            if not completion_date:
                continue
            # Преобразуем дату в нужный формат
            try:
                date_str = self.parent_ref.parse_date(completion_date)
                if not date_str:
                    continue
            except:
                continue
            # Нормализуем адрес и фильтруем некорректные
            raw_address = str(request.get('placement', '')).strip()
            if self.parent_ref.is_invalid_address(raw_address):
                continue
            normalized_address = self.parent_ref.normalize_address_with_similarity(raw_address, self.employee_data['requests_data'])
            # Добавляем в статистику
            if date_str not in address_stats:
                address_stats[date_str] = {}
            if normalized_address not in address_stats[date_str]:
                address_stats[date_str][normalized_address] = 0
            address_stats[date_str][normalized_address] += 1
        return address_stats

    def calculate_workload_stats(self):
        """Расчет статистики по трудозатратам по дням"""
        workload_stats = {}
        for request in self.employee_data['requests_data']:
            # Получаем дату окончания работ
            completion_date = request.get('completion_date', '')
            if not completion_date:
                continue
            # Преобразуем дату в нужный формат
            try:
                date_str = self.parent_ref.parse_date(completion_date)
                if not date_str:
                    continue
            except:
                continue
            # Считаем трудозатраты для этой заявки
            request_minutes = 0
            for code in request['arm_codes']:
                code_minutes = self.parent_ref.get_code_minutes(code)
                request_minutes += code_minutes
            # Добавляем в статистику
            if date_str not in workload_stats:
                workload_stats[date_str] = {
                    'requests_count': 0,
                    'total_minutes': 0
                }
            workload_stats[date_str]['requests_count'] += 1
            workload_stats[date_str]['total_minutes'] += request_minutes
        return workload_stats

    def go_back(self):
        self.parent_ref.show_main_screen()


class SuspiciousActivityWidget(QWidget):
    def __init__(self, suspicious_data, parent=None):
        super().__init__(parent)
        self.suspicious_data = suspicious_data
        self.parent_ref = parent
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()
        # Заголовок
        title_label = QLabel("🚨 Подозрительная активность")
        title_label.setStyleSheet("""
        QLabel {
            color: #FFFFFF;
            font-size: 18px;
            font-weight: bold;
            padding: 15px;
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #E74C3C, stop:1 #C0392B);
            border-radius: 10px;
            text-align: center;
        }
        """)
        layout.addWidget(title_label)

        # Общая статистика
        total_cases = len(self.suspicious_data)
        total_requests = sum(len(employee_cases) for employee_cases in self.suspicious_data.values())
        stats_layout = QHBoxLayout()
        cases_label = QLabel(f"👥 Найдено сотрудников: {total_cases}")
        cases_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 14px;
            padding: 12px;
            background-color: #FDEDEC;
            border-radius: 6px;
            font-weight: bold;
            border: 2px solid #E74C3C;
        }
        """)
        requests_label = QLabel(f"🚩 Подозрительных случаев: {total_requests}")
        requests_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 14px;
            padding: 12px;
            background-color: #FEF9E7;
            border-radius: 6px;
            font-weight: bold;
            border: 2px solid #F39C12;
        }
        """)
        stats_layout.addWidget(cases_label)
        stats_layout.addWidget(requests_label)
        stats_layout.addStretch()
        layout.addLayout(stats_layout)

        # Таблица с подозрительной активностью
        self.activity_table = QTableWidget()
        self.activity_table.setColumnCount(6)
        self.activity_table.setHorizontalHeaderLabels(["👤 Сотрудник", "📍 Адрес", "📅 Дата", "⏰ Время первого визита", "🕒 Время новых заявок", "📊 Количество новых"])
        # Заполняем таблицу данными
        self.populate_activity_table()
        # Настройка стиля таблицы
        self.activity_table.setStyleSheet("""
        QTableWidget {
            background-color: white;
            border: 2px solid #E74C3C;
            border-radius: 8px;
            gridline-color: #FDEDEC;
            font-size: 11px;
        }
        QTableWidget::item {
            padding: 8px;
            border-bottom: 1px solid #FDEDEC;
            color: #2C3E50;
        }
        QTableWidget::item:selected {
            background-color: #E74C3C;
            color: white;
        }
        QHeaderView::section {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #C0392B, stop:1 #A93226);
            color: white;
            font-weight: bold;
            padding: 10px;
            border: none;
            font-size: 11px;
        }
        """)
        self.activity_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.activity_table.cellDoubleClicked.connect(self.on_case_double_click)
        layout.addWidget(self.activity_table)

        # Кнопка назад
        back_btn = QPushButton("⬅️ Назад")
        back_btn.setStyleSheet("""
        QPushButton {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #E74C3C, stop:1 #C0392B);
            color: white;
            border: none;
            border-radius: 6px;
            padding: 12px;
            font-size: 14px;
            font-weight: bold;
        }
        QPushButton:hover {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #C0392B, stop:1 #A93226);
        }
        QPushButton:pressed {
            background: #922B21;
        }
        """)
        back_btn.clicked.connect(self.go_back)
        layout.addWidget(back_btn)
        self.setLayout(layout)

    def populate_activity_table(self):
        activity_data = []
        for employee, cases in self.suspicious_data.items():
            for case in cases:
                activity_data.append({
                    'employee': employee,
                    'address': case['address'],
                    'date': case['date'],
                    'first_visit_time': case['first_visit_time'],
                    'new_requests_time': case['new_requests_time'],
                    'new_requests_count': case['new_requests_count'],
                    'suspicious_requests': case['suspicious_requests']
                })
        # Сортируем по количеству новых заявок (убывание)
        activity_data.sort(key=lambda x: x['new_requests_count'], reverse=True)
        self.activity_table.setRowCount(len(activity_data))
        for row, item in enumerate(activity_data):
            self.activity_table.setItem(row, 0, QTableWidgetItem(item['employee']))
            self.activity_table.setItem(row, 1, QTableWidgetItem(item['address']))
            self.activity_table.setItem(row, 2, QTableWidgetItem(item['date']))
            self.activity_table.setItem(row, 3, QTableWidgetItem(item['first_visit_time']))
            self.activity_table.setItem(row, 4, QTableWidgetItem(item['new_requests_time']))
            count_item = QTableWidgetItem(str(item['new_requests_count']))
            # Сохраняем ВСЕ данные заявок для этого случая
            count_item.setData(Qt.UserRole, {
                'employee': item['employee'],
                'address': item['address'],
                'date': item['date'],
                'first_visit_time': item['first_visit_time'],
                'new_requests_time': item['new_requests_time'],
                'new_requests_count': item['new_requests_count'],
                'suspicious_requests': self.get_all_requests_for_case(item)
            })
            self.activity_table.setItem(row, 5, count_item)

    def get_all_requests_for_case(self, case):
        """Получение всех заявок для данного случая из исходных данных"""
        all_requests = []
        # Ищем сотрудника в статистике
        if case['employee'] in self.parent_ref.employee_stats:
            employee_stats = self.parent_ref.employee_stats[case['employee']]
            # Ищем все заявки этого сотрудника для данного адреса и даты
            for request in employee_stats['requests_data']:
                if (self.parent_ref.normalize_address_with_similarity(request.get('placement', ''), employee_stats['requests_data']) == case['address'] and
                        self.parent_ref.parse_date(request.get('registration_date', '')) == case['date']):
                    # Добавляем все данные заявки
                    all_requests.append(request)
        return all_requests

    def on_case_double_click(self, row, column):
        """Обработка двойного клика по случаю"""
        if column == 5:  # Клик по количеству заявок
            item = self.activity_table.item(row, column)
            case_data = item.data(Qt.UserRole)
            if case_data:
                self.parent_ref.show_suspicious_requests(case_data)

    def go_back(self):
        self.parent_ref.show_main_screen()


class ToggleSwitch(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(60, 30)
        self.state = False
        self.setCursor(Qt.PointingHandCursor)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        # Фон переключателя
        if self.state:
            painter.setBrush(QColor("#4CAF50"))
        else:
            painter.setBrush(QColor("#CCCCCC"))
        painter.drawRoundedRect(0, 0, self.width(), self.height(), 15, 15)
        # Кнопка переключателя
        painter.setBrush(QColor("white"))
        if self.state:
            painter.drawEllipse(self.width() - 25, 5, 20, 20)
        else:
            painter.drawEllipse(5, 5, 20, 20)

    def mousePressEvent(self, event):
        self.state = not self.state
        self.update()
        self.toggled.emit(self.state)

    toggled = Signal(bool)


class ServiceStatsWithToggleWidget(QWidget):
    def __init__(self, service_stats, employee_stats, parent=None):
        super().__init__(parent)
        self.service_stats = service_stats
        self.employee_stats = employee_stats
        self.parent_ref = parent
        self.current_view = "table"  # "table" или "ktr"
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()
        # Заголовок
        title_label = QLabel("📊 Статистика в разрезе услуг")
        title_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 18px;
            font-weight: bold;
            padding: 15px;
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #3498DB, stop:1 #2980B9);
            border-radius: 10px;
            text-align: center;
            color: white;
        }
        """)
        layout.addWidget(title_label)

        # Переключатель вида - две кнопки
        toggle_layout = QHBoxLayout()
        toggle_layout.addStretch()
        # Кнопка "Таблица"
        self.table_button = QPushButton("📋 Таблица")
        self.table_button.setFixedSize(150, 35)
        self.table_button.setCheckable(True)
        self.table_button.setChecked(True)
        self.table_button.setStyleSheet("""
        QPushButton {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #3498DB, stop:1 #2980B9);
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            font-weight: bold;
        }
        QPushButton:checked {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #2980B9, stop:1 #2471A3);
            border: 2px solid #1F618D;
        }
        QPushButton:checked:hover {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #2471A3, stop:1 #1F618D);
        }
        QPushButton:!checked {
            background: #BDC3C7;
            color: #7F8C8D;
        }
        QPushButton:!checked:hover {
            background: #A6ACAF;
        }
        """)
        self.table_button.clicked.connect(self.show_table_view)
        # Кнопка "Средний КТР(ТБ/Услуга)"
        self.ktr_button = QPushButton("⏱️ Средний КТР(ТБ/Услуга)")
        self.ktr_button.setFixedSize(200, 35)
        self.ktr_button.setCheckable(True)
        self.ktr_button.setChecked(False)
        self.ktr_button.setStyleSheet("""
        QPushButton {
            background: #BDC3C7;
            color: #7F8C8D;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            font-weight: bold;
        }
        QPushButton:checked {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #27AE60, stop:1 #229954);
            color: white;
            border: 2px solid #1E8449;
        }
        QPushButton:checked:hover {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #229954, stop:1 #1E8449);
        }
        QPushButton:!checked:hover {
            background: #A6ACAF;
        }
        """)
        self.ktr_button.clicked.connect(self.show_ktr_view)
        toggle_layout.addWidget(self.table_button)
        toggle_layout.addWidget(self.ktr_button)
        toggle_layout.addStretch()
        layout.addLayout(toggle_layout)

        # Область для контента
        self.content_stack = QStackedWidget()
        # Вид таблицы
        self.table_widget = ServiceStatsWidget(self.service_stats, self.parent_ref)
        self.content_stack.addWidget(self.table_widget)
        # Вид среднего КТР
        self.ktr_widget = ServiceStatsGraphWidget(self.service_stats, self.employee_stats, self.parent_ref)
        self.content_stack.addWidget(self.ktr_widget)
        layout.addWidget(self.content_stack)
        self.setLayout(layout)

    def show_table_view(self):
        """Показ табличного представления"""
        self.current_view = "table"
        self.table_button.setChecked(True)
        self.ktr_button.setChecked(False)
        self.content_stack.setCurrentIndex(0)
        # Обновляем стили кнопок
        self.table_button.setStyleSheet("""
        QPushButton {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #3498DB, stop:1 #2980B9);
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            font-weight: bold;
        }
        QPushButton:checked {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #2980B9, stop:1 #2471A3);
            border: 2px solid #1F618D;
        }
        QPushButton:checked:hover {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #2471A3, stop:1 #1F618D);
        }
        """)
        self.ktr_button.setStyleSheet("""
        QPushButton {
            background: #BDC3C7;
            color: #7F8C8D;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            font-weight: bold;
        }
        QPushButton:checked {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #27AE60, stop:1 #229954);
            color: white;
            border: 2px solid #1E8449;
        }
        QPushButton:checked:hover {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #229954, stop:1 #1E8449);
        }
        QPushButton:!checked:hover {
            background: #A6ACAF;
        }
        """)

    def show_ktr_view(self):
        """Показ представления среднего КТР"""
        self.current_view = "ktr"
        self.table_button.setChecked(False)
        self.ktr_button.setChecked(True)
        self.content_stack.setCurrentIndex(1)
        # Обновляем стили кнопок
        self.table_button.setStyleSheet("""
        QPushButton {
            background: #BDC3C7;
            color: #7F8C8D;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            font-weight: bold;
        }
        QPushButton:checked {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #3498DB, stop:1 #2980B9);
            color: white;
            border: 2px solid #1F618D;
        }
        QPushButton:checked:hover {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #2980B9, stop:1 #2471A3);
        }
        QPushButton:!checked:hover {
            background: #A6ACAF;
        }
        """)
        self.ktr_button.setStyleSheet("""
        QPushButton {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #27AE60, stop:1 #229954);
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            font-weight: bold;
        }
        QPushButton:checked {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #229954, stop:1 #1E8449);
            border: 2px solid #196F3D;
        }
        QPushButton:checked:hover {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #1E8449, stop:1 #196F3D;
        }
        """)


class ExcelAnalyzerApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.df = None
        self.ktr_df = None
        self.employee_stats = {}
        self.service_stats = {}
        self.current_terbank = "Все тербанки"
        self.current_user_type = "Все"  # "Все", "User", "Not User"
        self.current_rpr_filter = "Все"  # "Все", "Только РПР", "Без РПР"
        self.terbank_buttons = {}
        self.address_cache = {}
        self.code_descriptions = {}  # Словарь для хранения описаний кодов из КТР
        self.code_minutes = {}  # Словарь для хранения нормативов времени из КТР
        self.code_service_info = {}  # Словарь для хранения информации о кодах и услугах из КТР
        # Создаем stacked widget для навигации
        self.stacked_widget = QStackedWidget()
        self.setCentralWidget(self.stacked_widget)
        self.initUI()

    def initUI(self):
        self.setWindowTitle("📊 Анализатор Excel файлов - Статистика по сотрудникам")
        self.setGeometry(100, 100, 1400, 900)
        # Создаем главный экран
        self.main_screen = self.create_main_screen()
        self.stacked_widget.addWidget(self.main_screen)
        # Создаем экран деталей сотрудника (будет заполнен позже)
        self.employee_detail_screen = QWidget()
        self.stacked_widget.addWidget(self.employee_detail_screen)
        # Создаем экран ТОП-20 (будет заполнен позже)
        self.top20_screen = QWidget()
        self.stacked_widget.addWidget(self.top20_screen)
        # Создаем экран ТОП-20 по эффективности (будет заполнен позже)
        self.top20_efficiency_screen = QWidget()
        self.stacked_widget.addWidget(self.top20_efficiency_screen)
        # Создаем экран деталей кода (будет заполнен позже)
        self.code_detail_screen = QWidget()
        self.stacked_widget.addWidget(self.code_detail_screen)
        # Создаем экран статистики адресов (будет заполнен позже)
        self.address_stats_screen = QWidget()
        self.stacked_widget.addWidget(self.address_stats_screen)
        # Создаем экран статистики трудозатрат (будет заполнен позже)
        self.workload_stats_screen = QWidget()
        self.stacked_widget.addWidget(self.workload_stats_screen)
        # Создаем экран статистики услуг (будет заполнен позже)
        self.service_stats_screen = QWidget()
        self.stacked_widget.addWidget(self.service_stats_screen)
        # Создаем экран деталей услуги (будет заполнен позже)
        self.service_detail_screen = QWidget()
        self.stacked_widget.addWidget(self.service_detail_screen)
        # Создаем экран кодов услуги (будет заполнен позже)
        self.service_codes_screen = QWidget()
        self.stacked_widget.addWidget(self.service_codes_screen)
        # Создаем экран подозрительной активности (будет заполнен позже)
        self.suspicious_activity_screen = QWidget()
        self.stacked_widget.addWidget(self.suspicious_activity_screen)
        # Создаем экран всех заявок сотрудника (будет заполнен позже)
        self.employee_requests_screen = QWidget()
        self.stacked_widget.addWidget(self.employee_requests_screen)
        # Создаем экран подозрительных заявок (будет заполнен позже)
        self.suspicious_requests_screen = QWidget()
        self.stacked_widget.addWidget(self.suspicious_requests_screen)
        # Создаем экран всех заявок (будет заполнен позже)
        self.all_requests_screen = QWidget()
        self.stacked_widget.addWidget(self.all_requests_screen)
        # Создаем экран заявок по коду услуги (будет заполнен позже)
        self.service_code_requests_screen = QWidget()
        self.stacked_widget.addWidget(self.service_code_requests_screen)
        # Создаем экран КТР по тербанкам для услуги (будет заполнен позже)
        self.service_terbank_ktr_screen = QWidget()
        self.stacked_widget.addWidget(self.service_terbank_ktr_screen)

    def create_main_screen(self):
        """Создание главного экрана"""
        main_widget = QWidget()
        layout = QVBoxLayout(main_widget)
        layout.setSpacing(10)
        layout.setContentsMargins(20, 15, 20, 15)  # Одинаковые отступы слева и справа
        # Верхняя панель с информацией
        top_layout = QHBoxLayout()
        # Заголовок приложения
        title_label = QLabel("📊 Анализатор статистики сотрудников")
        title_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 20px;
            font-weight: bold;
            padding: 10px;
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #3498DB, stop:1 #2980B9);
            border-radius: 8px;
            color: white;
        }
        """)
        top_layout.addWidget(title_label)
        top_layout.addStretch()
        # Добавляем элементы в верхний layout
        layout.addLayout(top_layout)
        # Область загрузки файлов
        files_layout = QHBoxLayout()
        # Область загрузки обязательного файла КТР
        ktr_upload_layout = QVBoxLayout()
        ktr_upload_container = QWidget()
        ktr_upload_container.setFixedHeight(120)  # Увеличил высоту
        ktr_upload_container.setStyleSheet("""
        QWidget {
            background-color: #FFFFFF;
            border: 2px solid #3498DB;
            border-radius: 8px;
            padding: 12px;
        }
        """)
        ktr_upload_container_layout = QVBoxLayout(ktr_upload_container)
        # Заголовок для обязательного файла
        ktr_title_layout = QHBoxLayout()
        ktr_title_label = QLabel("📋 Файл КТР (обязательный)")
        ktr_title_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 16px;
            font-weight: bold;
        }
        """)
        # Кнопка информации для КТР
        ktr_info_button = QPushButton("💡 Подсказка")
        ktr_info_button.setFixedSize(90, 35)
        ktr_info_button.setStyleSheet("""
        QPushButton {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #3498DB, stop:1 #2980B9);
            color: white;
            border-radius: 6px;
            font-weight: bold;
            font-size: 12px;
        }
        QPushButton:hover {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #2980B9, stop:1 #2471A3);
        }
        """)
        ktr_info_button.clicked.connect(self.show_ktr_info)
        ktr_title_layout.addWidget(ktr_title_label)
        ktr_title_layout.addWidget(ktr_info_button)
        ktr_title_layout.addStretch()
        ktr_upload_container_layout.addLayout(ktr_title_layout)
        # Кнопка загрузки КТР файла
        ktr_buttons_layout = QHBoxLayout()
        self.ktr_upload_button = QPushButton("📁 Загрузить КТР")
        self.ktr_upload_button.setFixedSize(140, 40)
        self.ktr_upload_button.setStyleSheet("""
        QPushButton {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #3498DB, stop:1 #2980B9);
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            font-weight: bold;
        }
        QPushButton:hover {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #2980B9, stop:1 #2471A3);
        }
        QPushButton:disabled {
            background-color: #B8D4FF;
            color: #6C757D;
        }
        """)
        self.ktr_upload_button.clicked.connect(self.load_ktr_file)
        # Метка для отображения имени загруженного КТР файла
        self.ktr_file_label = QLabel("❌ Файл не выбран")
        self.ktr_file_label.setStyleSheet("""
        QLabel {
            color: #E74C3C;
            font-size: 12px;
            font-weight: bold;
            padding: 8px;
        }
        """)
        self.ktr_file_label.setWordWrap(True)
        self.ktr_file_label.setMaximumWidth(400)  # Увеличил максимальную ширину
        ktr_buttons_layout.addWidget(self.ktr_upload_button)
        ktr_buttons_layout.addWidget(self.ktr_file_label)
        ktr_buttons_layout.addStretch()
        ktr_upload_container_layout.addLayout(ktr_buttons_layout)
        ktr_upload_layout.addWidget(ktr_upload_container)
        # Область загрузки файла для обработки
        upload_layout = QVBoxLayout()
        upload_container = QWidget()
        upload_container.setFixedHeight(120)  # Увеличил высоту
        upload_container.setStyleSheet("""
        QWidget {
            background-color: #FFFFFF;
            border: 2px solid #3498DB;
            border-radius: 8px;
            padding: 12px;
        }
        """)
        upload_container_layout = QVBoxLayout(upload_container)
        # Заголовок для файла обработки
        upload_title_layout = QHBoxLayout()
        upload_title_label = QLabel("📊 Файл для обработки")
        upload_title_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 16px;
            font-weight: bold;
        }
        """)
        # Кнопка информации для файла обработки
        upload_info_button = QPushButton("💡 Подсказка")
        upload_info_button.setFixedSize(90, 40)
        upload_info_button.setStyleSheet("""
        QPushButton {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #3498DB, stop:1 #2980B9);
            color: white;
            border-radius: 6px;
            font-weight: bold;
            font-size: 12px;
        }
        QPushButton:hover {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #2980B9, stop:1 #2471A3);
        }
        """)
        upload_info_button.clicked.connect(self.show_upload_info)
        upload_title_layout.addWidget(upload_title_label)
        upload_title_layout.addWidget(upload_info_button)
        upload_title_layout.addStretch()
        upload_container_layout.addLayout(upload_title_layout)
        # Кнопка загрузки файла
        upload_buttons_layout = QHBoxLayout()
        self.upload_button = QPushButton("📁 Загрузить файл")
        self.upload_button.setFixedSize(140, 40)
        self.upload_button.setStyleSheet("""
        QPushButton {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #3498DB, stop:1 #2980B9);
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            font-weight: bold;
        }
        QPushButton:hover {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #2980B9, stop:1 #2471A3);
        }
        QPushButton:disabled {
            background-color: #B8D4FF;
            color: #6C757D;
        }
        """)
        self.upload_button.clicked.connect(self.load_excel_file)
        self.upload_button.setEnabled(False)  # Изначально отключена
        # Метка для отображения имени загруженного файла
        self.file_label = QLabel("❌ Файл не выбран")
        self.file_label.setStyleSheet("""
        QLabel {
            color: #6C757D;
            font-size: 12px;
            font-style: italic;
            padding: 8px;
        }
        """)
        self.file_label.setWordWrap(True)
        self.file_label.setMaximumWidth(400)  # Увеличил максимальную ширину
        upload_buttons_layout.addWidget(self.upload_button)
        upload_buttons_layout.addWidget(self.file_label)
        upload_buttons_layout.addStretch()
        upload_container_layout.addLayout(upload_buttons_layout)
        upload_layout.addWidget(upload_container)
        files_layout.addLayout(ktr_upload_layout)
        files_layout.addSpacing(15)
        files_layout.addLayout(upload_layout)
        layout.addLayout(files_layout)
        # Панель управления с фильтрами
        control_layout = QVBoxLayout()
        # Верхняя строка с кнопками ТОП-20 и фильтром по типу пользователя
        top_buttons_layout = QHBoxLayout()
        # Кнопка ТОП-20 по количеству заявок
        self.top20_button = QPushButton("🏆 ТОП-20 (заявки)")
        self.top20_button.setFixedSize(140, 35)
        self.top20_button.setStyleSheet("""
        QPushButton {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #F39C12, stop:1 #E67E22);
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 12px;
            font-weight: bold;
        }
        QPushButton:hover {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #E67E22, stop:1 #D35400);
        }
        QPushButton:disabled {
            background-color: #B8D4FF;
            color: #6C757D;
        }
        """)
        self.top20_button.clicked.connect(self.show_top20)
        self.top20_button.setEnabled(False)
        # Кнопка ТОП-20 по эффективности
        self.top20_efficiency_button = QPushButton("⚡ ТОП-20 (эффективность)")
        self.top20_efficiency_button.setFixedSize(180, 35)
        self.top20_efficiency_button.setStyleSheet("""
        QPushButton {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #9B59B6, stop:1 #8E44AD);
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 12px;
            font-weight: bold;
        }
        QPushButton:hover {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #8E44AD, stop:1 #7D3C98);
        }
        QPushButton:disabled {
            background-color: #B8D4FF;
            color: #6C757D;
        }
        """)
        self.top20_efficiency_button.clicked.connect(self.show_top20_efficiency)
        self.top20_efficiency_button.setEnabled(False)
        # Кнопка статистики услуг
        self.services_button = QPushButton("📊 Статистика в разрезе услуг")
        self.services_button.setFixedSize(200, 35)
        self.services_button.setStyleSheet("""
        QPushButton {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #3498DB, stop:1 #2980B9);
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 12px;
            font-weight: bold;
        }
        QPushButton:hover {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #2980B9, stop:1 #2471A3);
        }
        QPushButton:disabled {
            background-color: #B8D4FF;
            color: #6C757D;
        }
        """)
        self.services_button.clicked.connect(self.show_service_stats)
        self.services_button.setEnabled(False)
        # Кнопка подозрительной активности
        self.suspicious_button = QPushButton("🚨 Подозрительная активность")
        self.suspicious_button.setFixedSize(200, 35)
        self.suspicious_button.setStyleSheet("""
        QPushButton {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #E74C3C, stop:1 #C0392B);
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 12px;
            font-weight: bold;
        }
        QPushButton:hover {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #C0392B, stop:1 #A93226);
        }
        QPushButton:disabled {
            background-color: #B8D4FF;
            color: #6C757D;
        }
        """)
        self.suspicious_button.clicked.connect(self.show_suspicious_activity)
        self.suspicious_button.setEnabled(False)
        top_buttons_layout.addWidget(self.top20_button)
        top_buttons_layout.addWidget(self.top20_efficiency_button)
        top_buttons_layout.addWidget(self.services_button)
        top_buttons_layout.addWidget(self.suspicious_button)
        top_buttons_layout.addStretch()
        control_layout.addLayout(top_buttons_layout)
        # Строка с фильтрами User/Not User и РПР
        filters_layout = QHBoxLayout()
        # Фильтр по типу пользователя
        user_type_layout = QHBoxLayout()
        user_type_label = QLabel("👤 Тип запросов:")
        user_type_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 12px;
            font-weight: bold;
        }
        """)
        self.user_type_combo = QComboBox()
        self.user_type_combo.addItems(["Все", "User", "Not User"])
        self.user_type_combo.setFixedSize(120, 30)
        self.user_type_combo.setStyleSheet("""
        QComboBox {
            background-color: white;
            border: 2px solid #3498DB;
            border-radius: 6px;
            padding: 3px;
            font-size: 12px;
            color: #2C3E50;
        }
        QComboBox:disabled {
            background-color: #F0F7FF;
            color: #6C757D;
        }
        """)
        self.user_type_combo.currentTextChanged.connect(self.on_user_type_changed)
        self.user_type_combo.setEnabled(False)
        user_type_layout.addWidget(user_type_label)
        user_type_layout.addWidget(self.user_type_combo)
        # Фильтр РПР
        rpr_filter_layout = QHBoxLayout()
        rpr_label = QLabel("🔍 Фильтр РПР:")
        rpr_label.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 12px;
            font-weight: bold;
        }
        """)
        self.rpr_combo = QComboBox()
        self.rpr_combo.addItems(["Все", "Только РПР", "Без РПР"])
        self.rpr_combo.setFixedSize(120, 30)
        self.rpr_combo.setStyleSheet("""
        QComboBox {
            background-color: white;
            border: 2px solid #3498DB;
            border-radius: 6px;
            padding: 3px;
            font-size: 12px;
            color: #2C3E50;
        }
        QComboBox:disabled {
            background-color: #F0F7FF;
            color: #6C757D;
        }
        """)
        self.rpr_combo.currentTextChanged.connect(self.on_rpr_filter_changed)
        self.rpr_combo.setEnabled(False)
        rpr_filter_layout.addWidget(rpr_label)
        rpr_filter_layout.addWidget(self.rpr_combo)
        filters_layout.addLayout(user_type_layout)
        filters_layout.addSpacing(20)
        filters_layout.addLayout(rpr_filter_layout)
        filters_layout.addStretch()
        control_layout.addLayout(filters_layout)
        # Заголовок для тербанков
        terbank_title_layout = QHBoxLayout()
        terbank_title = QLabel("🏢 Тербанки:")
        terbank_title.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 12px;
            font-weight: bold;
        }
        """)
        terbank_title_layout.addWidget(terbank_title)
        terbank_title_layout.addStretch()
        control_layout.addLayout(terbank_title_layout)
        # Область с кнопками тербанков и кнопкой "Показать все"
        terbank_buttons_layout = QHBoxLayout()
        # Кнопка "Показать все" в начале списка тербанков
        self.show_all_button = QPushButton("👁️ Показать все")
        self.show_all_button.setFixedSize(100, 25)
        self.show_all_button.setStyleSheet("""
        QPushButton {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #3498DB, stop:1 #2980B9);
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 10px;
            font-weight: bold;
        }
        QPushButton:hover {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #2980B9, stop:1 #2471A3);
        }
        QPushButton:disabled {
            background-color: #B8D4FF;
            color: #6C757D;
        }
        """)
        self.show_all_button.clicked.connect(lambda: self.filter_by_terbank("Все тербанки"))
        self.show_all_button.setEnabled(False)
        terbank_buttons_layout.addWidget(self.show_all_button)
        # Область с кнопками тербанков
        self.terbanks_scroll = QScrollArea()
        self.terbanks_scroll.setFixedHeight(45)
        self.terbanks_scroll.setWidgetResizable(True)
        self.terbanks_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.terbanks_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.terbanks_scroll.setStyleSheet("""
        QScrollArea {
            border: 2px solid #3498DB;
            border-radius: 6px;
            background-color: #FFFFFF;
        }
        """)
        self.terbanks_widget = QWidget()
        self.terbanks_layout = QHBoxLayout(self.terbanks_widget)
        self.terbanks_layout.setSpacing(3)
        self.terbanks_layout.setContentsMargins(5, 3, 5, 3)
        self.terbanks_scroll.setWidget(self.terbanks_widget)
        terbank_buttons_layout.addWidget(self.terbanks_scroll)
        control_layout.addLayout(terbank_buttons_layout)
        layout.addLayout(control_layout)
        # Основная рабочая область - статистика по сотрудникам
        table_title = QLabel("📈 Статистика по сотрудникам")
        table_title.setStyleSheet("""
        QLabel {
            color: #2C3E50;
            font-size: 16px;
            font-weight: bold;
            padding: 10px;
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #3498DB, stop:1 #2980B9);
            border-radius: 6px;
            color: white;
        }
        """)
        layout.addWidget(table_title)
        # Таблица для отображения статистики - занимает 50% от экрана
        self.stats_table = QTableWidget()
        self.stats_table.setColumnCount(5)  # Добавил колонку для дней
        self.stats_table.setHorizontalHeaderLabels(["👤 ФИО сотрудника", "🏢 Тербанк", "📊 Заявок", "📅 Период", "📅 Дней"])
        self.stats_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.stats_table.setRowCount(0)
        # Устанавливаем размер таблицы - 50% от высоты экрана
        self.stats_table.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        # Включаем сортировку
        self.stats_table.setSortingEnabled(True)
        # Стиль таблицы
        self.stats_table.setStyleSheet("""
        QTableWidget {
            background-color: white;
            border: 2px solid #3498DB;
            border-radius: 8px;
            gridline-color: #D6EAF8;
            font-size: 11px;
        }
        QTableWidget::item {
            padding: 6px;
            border-bottom: 1px solid #D6EAF8;
            color: #2C3E50;
        }
        QTableWidget::item:selected {
            background-color: #3498DB;
            color: white;
        }
        QHeaderView::section {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #2980B9, stop:1 #2471A3);
            color: white;
            font-weight: bold;
            padding: 8px;
            border: none;
            font-size: 11px;
        }
        """)
        # Двойной клик по таблице для деталей
        self.stats_table.cellDoubleClicked.connect(self.on_table_double_click)
        layout.addWidget(self.stats_table, 1)  # Коэффициент растяжения 1 для основной таблицы
        # Статусная строка
        self.status_label = QLabel("📝 Загрузите обязательный файл КТР для начала работы")
        self.status_label.setStyleSheet("""
        QLabel {
            color: #856404;
            font-size: 11px;
            padding: 8px;
            background-color: #FFF3CD;
            border-radius: 6px;
            border-left: 4px solid #FFC107;
        }
        """)
        layout.addWidget(self.status_label)
        return main_widget

    def parse_date(self, date_value):
        """Безопасный парсинг даты с обработкой ошибок"""
        if not date_value or pd.isna(date_value) or str(date_value).strip() in ['', '-', 'None', 'nan']:
            return None
        try:
            # Если это уже datetime объект
            if isinstance(date_value, (datetime, pd.Timestamp)):
                return date_value.strftime('%d.%m.%Y')
            date_str = str(date_value).strip()
            # Пропускаем пустые значения и прочерки
            if not date_str or date_str == '-' or date_str.lower() in ['none', 'nan', 'null']:
                return None
            # Пробуем разные форматы дат
            formats = [
                '%Y-%m-%d %H:%M:%S',
                '%Y-%m-%d',
                '%d.%m.%Y %H:%M:%S',
                '%d.%m.%Y',
                '%d/%m/%Y %H:%M:%S',
                '%d/%m/%Y',
                '%m/%d/%Y %H:%M:%S',
                '%m/%d/%Y'
            ]
            for fmt in formats:
                try:
                    date_obj = datetime.strptime(date_str, fmt)
                    return date_obj.strftime('%d.%m.%Y')
                except ValueError:
                    continue
            # Если ни один формат не подошел, пытаемся разобрать как есть
            date_obj = pd.to_datetime(date_str, errors='coerce')
            if pd.notna(date_obj):
                return date_obj.strftime('%d.%m.%Y')
            return None
        except Exception as e:
            print(f"Ошибка парсинга даты '{date_value}': {e}")
            return None

    def parse_datetime(self, date_value):
        """Парсинг даты и времени для временных интервалов"""
        if not date_value or pd.isna(date_value) or str(date_value).strip() in ['', '-', 'None', 'nan']:
            return None
        try:
            # Если это уже datetime объект
            if isinstance(date_value, (datetime, pd.Timestamp)):
                return date_value
            date_str = str(date_value).strip()
            # Пропускаем пустые значения и прочерки
            if not date_str or date_str == '-' or date_str.lower() in ['none', 'nan', 'null']:
                return None
            # Пробуем разные форматы дат
            formats = [
                '%Y-%m-%d %H:%M:%S',
                '%Y-%m-%d',
                '%d.%m.%Y %H:%M:%S',
                '%d.%m.%Y',
                '%d/%m/%Y %H:%M:%S',
                '%d/%m/%Y',
                '%m/%d/%Y %H:%M:%S',
                '%m/%d/%Y'
            ]
            for fmt in formats:
                try:
                    date_obj = datetime.strptime(date_str, fmt)
                    return date_obj
                except ValueError:
                    continue
            # Если ни один формат не подошел, пытаемся разобрать как есть
            date_obj = pd.to_datetime(date_str, errors='coerce')
            if pd.notna(date_obj):
                return date_obj.to_pydatetime()
            return None
        except Exception as e:
            print(f"Ошибка парсинга даты и времени '{date_value}': {e}")
            return None

    def is_invalid_address(self, address):
        """Проверяет, является ли адрес некорректным (пустой, только цифры и т.д.)"""
        if not address or pd.isna(address) or str(address).strip() in ['', '-', 'None', 'nan']:
            return True
        address_str = str(address).strip()
        # Проверяем, состоит ли адрес только из цифр
        if re.match(r'^\d+$', address_str):
            return True
        # Проверяем слишком короткие адреса (менее 3 символов)
        if len(address_str) < 3:
            return True
        # Проверяем распространенные некорректные значения
        invalid_patterns = [
            r'^\d+$',  # только цифры
            r'^[0-9\s\-]+$',  # только цифры, пробелы и дефисы
            r'^null$', r'^undefined$', r'^none$',  # системные значения
        ]
        for pattern in invalid_patterns:
            if re.match(pattern, address_str.lower()):
                return True
        return False

    def load_ktr_file(self):
        """Загрузка обязательного файла КТР"""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Выберите файл КТР с портала ГС",
            "",
            "Excel Files (*.xlsx *.xls);;All Files (*)"
        )
        if file_path:
            try:
                self.status_label.setText("⏳ Загрузка файла КТР...")
                self.status_label.setStyleSheet("""
                QLabel {
                    color: #856404;
                    font-size: 11px;
                    padding: 8px;
                    background-color: #FFF3CD;
                    border-radius: 6px;
                    border-left: 4px solid #FFC107;
                }
                """)
                self.ktr_df = pd.read_excel(file_path)
                # Загружаем описания кодов и нормативы из КТР
                self.load_code_data()
                file_name = file_path.split('/')[-1]
                # Обрезаем длинное имя файла
                if len(file_name) > 30:
                    file_name = file_name[:27] + "..."
                self.ktr_file_label.setText(f"✅ {file_name}")
                self.ktr_file_label.setStyleSheet("""
                QLabel {
                    color: #155724;
                    font-size: 14px;
                    font-weight: bold;
                }
                """)
                # Активируем кнопку загрузки основного файла
                self.upload_button.setEnabled(True)
                self.status_label.setText("✅ Файл КТР загружен. Теперь загрузите файл для обработки")
                self.status_label.setStyleSheet("""
                QLabel {
                    color: #155724;
                    font-size: 11px;
                    padding: 8px;
                    background-color: #D4EDDA;
                    border-radius: 6px;
                    border-left: 4px solid #28A745;
                }
                """)
            except Exception as e:
                self.status_label.setText("❌ Ошибка при загрузке файла КТР")
                self.status_label.setStyleSheet("""
                QLabel {
                    color: #721C24;
                    font-size: 11px;
                    padding: 8px;
                    background-color: #F8D7DA;
                    border-radius: 6px;
                    border-left: 4px solid #DC3545;
                }
                """)
                QMessageBox.critical(self, "Ошибка", f"Ошибка при загрузке файла КТР: {str(e)}")

    def load_code_data(self):
        """Загрузка описаний кодов и нормативов времени из файла КТР"""
        self.code_descriptions = {}
        self.code_minutes = {}
        self.code_service_info = {}
        if self.ktr_df is None:
            return
        # Проверяем наличие необходимых колонок в КТР
        required_columns = ['Коды работ', 'Название работы', 'Название услуги', 'Норматив (сумма), мин']
        if 'ID услуги в сервисной системе заказчика' in self.ktr_df.columns:
            required_columns.append('ID услуги в сервисной системе заказчика')
        missing_columns = [col for col in required_columns if col not in self.ktr_df.columns]
        if missing_columns:
            QMessageBox.warning(self, "Внимание",
                                f"В файле КТР отсутствуют колонки: {', '.join(missing_columns)}\n"
                                f"Описания работ и нормативы не будут загружены.")
            return
        # Загружаем описания кодов и нормативы
        for index, row in self.ktr_df.iterrows():
            code = str(row['Коды работ']).strip()
            work_name = str(row['Название работы']).strip()
            service_name = str(row['Название услуги']).strip()
            service_id = str(row.get('ID услуги в сервисной системе заказчика', '')).strip() if 'ID услуги в сервисной системе заказчика' in self.ktr_df.columns else ''
            # Получаем норматив времени
            try:
                minutes = float(row['Норматив (сумма), мин']) if pd.notna(row['Норматив (сумма), мин']) else 0
            except (ValueError, TypeError):
                minutes = 0
            if code and code != 'nan':
                # Формируем полное описание
                full_description = f"{work_name} ({service_name})" if service_name and service_name != 'nan' else work_name
                self.code_descriptions[code] = full_description
                self.code_minutes[code] = minutes
                self.code_service_info[code] = {
                    'work_name': work_name,
                    'service_name': service_name,
                    'service_id': service_id
                }

    def get_code_description(self, arm_code):
        """Получение описания работы по коду ARM из КТР"""
        # Убираем # из кода ARM#0100000# -> 0100000
        clean_code = arm_code.replace('#', '')
        # Ищем описание в загруженных данных
        if clean_code in self.code_descriptions:
            return self.code_descriptions[clean_code]
        return "Описание не найдено"

    def get_code_minutes(self, arm_code):
        """Получение норматива времени по коду ARM из КТР"""
        # Убираем # из кода ARM#0100000# -> 0100000
        clean_code = arm_code.replace('#', '')
        # Ищем норматив в загруженных данных
        if clean_code in self.code_minutes:
            return self.code_minutes[clean_code]
        return 0  # Если норматив не найден, возвращаем 0 минут

    def get_service_codes_data(self, service_name):
        """Получение данных о кодах ARM для конкретной услуги"""
        service_codes_data = {}
        # Проходим по всем заявкам и находим коды для этой услуги
        for employee_stats in self.employee_stats.values():
            for request in employee_stats['requests_data']:
                if request.get('service', '') == service_name:
                    for code in request['arm_codes']:
                        clean_code = code.replace('#', '')
                        if clean_code in service_codes_data:
                            service_codes_data[clean_code]['count'] += 1
                        else:
                            # Получаем информацию о коде из КТР
                            code_info = self.code_service_info.get(clean_code, {})
                            service_codes_data[clean_code] = {
                                'work_name': code_info.get('work_name', 'Не найдено'),
                                'service_id': code_info.get('service_id', 'Не найден'),
                                'count': 1
                            }
        return service_codes_data

    def show_ktr_info(self):
        """Показ информации о файле КТР"""
        info_text = """
        ТРЕБОВАНИЯ К ФАЙЛУ КТР:
        Загружаем актуальный файл КТР с портала ГС:
        • Обязательные колонки и их точные названия которые ищет инструмент:
        - 'Коды работ'
        - 'Название работы'
        - 'Название услуги'
        - 'Норматив (сумма),
        - 'ID услуги в сервисной системе заказчика'
        Если код выдает ошибку переименуйте все колонки согласно тексту выше в файле Excel
        📥 Скачать актуальный файл КТР можно по ссылке: 0101
        """
        # Создаем QMessageBox с увеличенным размером
        msg = QMessageBox(self)
        msg.setWindowTitle("Информация о файле КТР")
        msg.setText(info_text.strip())
        msg.setIcon(QMessageBox.Information)
        msg.setStyleSheet("""
        QMessageBox {
            min-width: 600px;
            min-height: 400px;
        }
        QMessageBox QLabel {
            font-size: 12px;
            line-height: 1.4;
        }
        """)
        msg.exec()

    def show_upload_info(self):
        """Показ информации о файле для обработки"""
        info_text = """
        ИНФОРМАЦИЯ О ФАЙЛЕ ДЛЯ ОБРАБОТКИ:
        ТРЕБОВАНИЯ К ФАЙЛУ:
        Выгружаем из SMFull_Info.
        Обязательные колонки и их точные названия которые ищет инструмент:
        - 'Решение'
        - 'Дата и время окончания работ'
        - 'Тербанк'
        - 'Тип пользователя'
        - 'Размещение'
        - 'Запрос'
        - 'Услуга (Объект)'
        Если код выдает ошибку переименуйте все колонки согласно тексту выше в файле Excel
        """
        # Создаем QMessageBox с увеличенным размером
        msg = QMessageBox(self)
        msg.setWindowTitle("Информация о файле обработки")
        msg.setText(info_text.strip())
        msg.setIcon(QMessageBox.Information)
        msg.setStyleSheet("""
        QMessageBox {
            min-width: 600px;
            min-height: 450px;
        }
        QMessageBox QLabel {
            font-size: 12px;
            line-height: 1.4;
        }
        """)
        msg.exec()

    def on_user_type_changed(self, user_type):
        """Обработка изменения типа пользователя"""
        self.current_user_type = user_type
        if self.df is not None:
            self.process_data()
            self.display_statistics(self.current_terbank)

    def on_rpr_filter_changed(self, rpr_filter):
        """Обработка изменения фильтра РПР"""
        self.current_rpr_filter = rpr_filter
        if self.df is not None:
            self.process_data()
            self.display_statistics(self.current_terbank)

    def extract_employee_info(self, solution_text, terbank):
        """Извлечение информации о сотруднике из текста решения"""
        if not isinstance(solution_text, str):
            return None, []
        # Ищем коды ARM
        arm_codes = re.findall(r'#ARM\d+#', solution_text)
        # Ищем ФИО сотрудника (после "Исполнитель:") - только русские буквы и пробелы
        fio_match = re.search(r'Исполнитель:[^,]+,([^,]+),', solution_text)
        if fio_match:
            # Оставляем только русские буквы, пробелы и дефисы
            fio = re.sub(r'[^а-яА-ЯёЁ\s-]', '', fio_match.group(1)).strip()
            if fio and not any(word in fio.lower() for word in ['ул', 'улица', 'адрес', 'доваторцев']):  # Фильтруем адреса
                return fio, arm_codes
        return None, arm_codes

    def is_rpr_request(self, detailed_description):
        """Проверяет, является ли заявка РПР"""
        if not isinstance(detailed_description, str):
            return False
        return '#RPR' in detailed_description.upper()

    def process_data(self):
        """Обработка данных и расчет статистики"""
        if self.df is None:
            return
        # Проверяем наличие необходимых колонок
        required_columns = ['Решение', 'Дата и время окончания работ']
        missing_columns = [col for col in required_columns if col not in self.df.columns]
        if missing_columns:
            QMessageBox.warning(self, "Ошибка", f"Отсутствуют необходимые колонки: {', '.join(missing_columns)}")
            return
        # Фильтрация по типу пользователя
        filtered_df = self.df
        if 'Тип пользователя' in self.df.columns:
            if self.current_user_type == "User":
                filtered_df = self.df[self.df['Тип пользователя'] == 'User']
            elif self.current_user_type == "Not User":
                filtered_df = self.df[self.df['Тип пользователя'] == 'Not User']
        # Фильтрация по РПР
        if 'Подробное описание' in filtered_df.columns:
            if self.current_rpr_filter == "Только РПР":
                filtered_df = filtered_df[filtered_df['Подробное описание'].apply(self.is_rpr_request)]
            elif self.current_rpr_filter == "Без РПР":
                filtered_df = filtered_df[~filtered_df['Подробное описание'].apply(self.is_rpr_request)]
        self.employee_stats = {}
        self.service_stats = {}
        terbanks = set()
        # Обрабатываем каждую строку для статистики
        for index, row in filtered_df.iterrows():
            solution_text = row['Решение']
            terbank = row.get('Тербанк', 'Не указан') if 'Тербанк' in filtered_df.columns else 'Не указан'
            if pd.notna(terbank):
                terbanks.add(str(terbank))
            fio, arm_codes = self.extract_employee_info(solution_text, terbank)
            if fio and arm_codes:
                # Используем дату окончания работ для периода сотрудника
                completion_date = row['Дата и время окончания работ']
                date_str = self.parse_date(completion_date)
                if date_str:
                    if fio not in self.employee_stats:
                        self.employee_stats[fio] = {
                            'total_requests': 0,
                            'arm_codes': {},
                            'work_dates': set(),  # Уникальные даты работы
                            'terbank': terbank,
                            'total_workload_minutes': 0,
                            'requests_data': []  # Сохраняем исходные данные заявок
                        }
                    self.employee_stats[fio]['total_requests'] += 1
                    self.employee_stats[fio]['work_dates'].add(date_str)
                    # Считаем трудозатраты для этой заявки
                    request_minutes = 0
                    for code in arm_codes:
                        code_minutes = self.get_code_minutes(code)
                        request_minutes += code_minutes
                    self.employee_stats[fio]['total_workload_minutes'] += request_minutes
                    # Сохраняем данные заявки
                    request_data = {
                        'request_number': row.get('Запрос', ''),
                        'placement': row.get('Размещение', ''),
                        'registration_date': row.get('Дата и время регистрации', ''),
                        'closing_date': row.get('Дата и время закрытия', ''),
                        'completion_date': completion_date,
                        'arm_codes': arm_codes,
                        'user_type': row.get('Тип пользователя', 'Не указан'),
                        'workload_minutes': request_minutes,
                        'service': row.get('Услуга (Объект)', '') if 'Услуга (Объект)' in row else '',
                        'is_rpr': self.is_rpr_request(row.get('Подробное описание', '')) if 'Подробное описание' in row else False
                    }
                    # Добавляем все остальные колонки из исходного файла
                    for col in filtered_df.columns:
                        if col not in request_data:
                            request_data[col] = row[col]
                    self.employee_stats[fio]['requests_data'].append(request_data)
                    # Статистика по кодам с описаниями из КТР
                    for code in arm_codes:
                        if code not in self.employee_stats[fio]['arm_codes']:
                            description = self.get_code_description(code)
                            self.employee_stats[fio]['arm_codes'][code] = {
                                'count': 0,
                                'description': description
                            }
                        self.employee_stats[fio]['arm_codes'][code]['count'] += 1
                    # Статистика по услугам
                    service_name = row.get('Услуга (Объект)', '')
                    if service_name and pd.notna(service_name) and str(service_name).strip() not in ['', 'nan']:
                        service_code = str(service_name).strip()
                        if service_code not in self.service_stats:
                            self.service_stats[service_code] = {
                                'service_name': service_code,
                                'total_requests': 0,
                                'arm_codes': {},
                                'work_dates': set()
                            }
                        self.service_stats[service_code]['total_requests'] += 1
                        self.service_stats[service_code]['work_dates'].add(date_str)
                        # Собираем коды ARM для этой услуги
                        for code in arm_codes:
                            clean_code = code.replace('#', '')
                            if clean_code not in self.service_stats[service_code]['arm_codes']:
                                # Получаем информацию о коде из КТР
                                code_info = self.code_service_info.get(clean_code, {})
                                self.service_stats[service_code]['arm_codes'][clean_code] = {
                                    'work_name': code_info.get('work_name', 'Не найдено'),
                                    'service_id': code_info.get('service_id', 'Не найден'),
                                    'count': 0
                                }
                            self.service_stats[service_code]['arm_codes'][clean_code]['count'] += 1
        # Рассчитываем периоды для каждого сотрудника
        for fio, stats in self.employee_stats.items():
            if stats['work_dates']:
                # Сортируем даты и находим период
                sorted_dates = sorted(stats['work_dates'])
                start_date = sorted_dates[0]
                end_date = sorted_dates[-1]
                work_days = len(stats['work_dates'])
                stats['period'] = f"{start_date} - {end_date}"
                stats['work_days'] = work_days
            else:
                stats['period'] = "Период не определен"
                stats['work_days'] = 0
        # Рассчитываем периоды для каждой услуги
        for service_code, stats in self.service_stats.items():
            if stats['work_dates']:
                sorted_dates = sorted(stats['work_dates'])
                start_date = sorted_dates[0]
                end_date = sorted_dates[-1]
                stats['period'] = f"{start_date} - {end_date}"
            else:
                stats['period'] = "Период не определен"
        # Создаем кнопки тербанков
        self.create_terbank_buttons(terbanks)
        self.display_statistics()

    def create_terbank_buttons(self, terbanks):
        """Создание кнопки тербанков"""
        # Очищаем старые кнопки
        for button in self.terbank_buttons.values():
            button.deleteLater()
        self.terbank_buttons.clear()
        # Собираем уникальные тербанки, для которых есть сотрудники
        active_terbanks = set()
        for stats in self.employee_stats.values():
            if stats['terbank'] and stats['terbank'] != "Не указан":
                active_terbanks.add(stats['terbank'])
        # Создаем кнопки только для активных тербанков
        for terbank in sorted(active_terbanks):
            button = QPushButton(f"{terbank}")
            button.setFixedSize(120, 25)
            button.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                            stop:0 #3498DB, stop:1 #2980B9);
                color: white;
                border: none;
                border-radius: 6px;
                font-size: 10px;
                font-weight: bold;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                            stop:0 #2980B9, stop:1 #2471A3);
            }
            """)
            button.clicked.connect(lambda checked, t=terbank: self.filter_by_terbank(t))
            self.terbank_buttons[terbank] = button
            self.terbanks_layout.addWidget(button)
        self.terbanks_layout.addStretch()

    def normalize_address_with_similarity(self, address, all_requests):
        """Умная нормализация адреса с учетом схожести"""
        if self.is_invalid_address(address):
            return "Адрес не определен"
        # Базовая нормализация
        normalized = self.basic_normalize_address(address)
        # Если адрес уже в кэше, возвращаем его
        if normalized in self.address_cache:
            return self.address_cache[normalized]
        # Ищем похожие адреса среди всех заявок сотрудника
        similar_addresses = []
        for request in all_requests:
            other_address = str(request.get('placement', '')).strip()
            if self.is_invalid_address(other_address):
                continue
            other_normalized = self.basic_normalize_address(other_address)
            similarity = SequenceMatcher(None, normalized, other_normalized).ratio()
            if similarity > 0.8:  # Порог схожести 80%
                similar_addresses.append(other_normalized)
        # Если есть похожие адреса, берем самый частый
        if similar_addresses:
            most_common = max(set(similar_addresses), key=similar_addresses.count)
            self.address_cache[normalized] = most_common
            return most_common
        # Иначе возвращаем базовую нормализацию
        self.address_cache[normalized] = normalized
        return normalized

    def basic_normalize_address(self, address):
        """Базовая нормализация адреса"""
        address = str(address).lower().strip()
        # Удаляем лишние символы
        address = re.sub(r'[^\w\sа-яё.,-]', ' ', address)
        address = re.sub(r'\s+', ' ', address)
        # Нормализуем регионы и города
        replacements = {
            r'край\s*ставропольский': 'ставропольский край',
            r'г\s*ставрополь': 'ставрополь',
            r'п\s*р-кт': 'проспект',
            r'пр-кт': 'проспект',
            r'ул\s*': 'улица ',
            r'улица\s*': 'улица ',
            r'пр-т': 'проспект',
            r'пр\.': 'проспект',
            r'пер\s*': 'переулок ',
            r'переулок\s*': 'переулок ',
            r'д\s*': 'дом ',
            r'дом\s*': 'дом ',
            r'кв\s*': 'квартира ',
            r'квартира\s*': 'квартира ',
            r'оф\s*': 'офис ',
            r'офис\s*': 'офис ',
            r'помещ\s*': 'помещение ',
            r'помещение\s*': 'помещение ',
            r'этаж\s*': 'этаж ',
            r'эт\s*': 'этаж ',
        }
        for pattern, replacement in replacements.items():
            address = re.sub(pattern, replacement, address)
        # Удаляем номера квартир, офисов и т.д.
        address = re.sub(r',\s*\d+[.,]?\d*[.,]?\d*[.,]?\d*', '', address)
        address = re.sub(r'\s+квартира\s*\d+', '', address)
        address = re.sub(r'\s+офис\s*\d+', '', address)
        address = re.sub(r'\s+помещение\s*\d+', '', address)
        address = re.sub(r'\s+этаж\s*\d+', '', address)
        # Удаляем лишние пробелы и приводим к красивому виду
        address = re.sub(r'\s+', ' ', address).strip()
        # Выделяем основные компоненты адреса
        components = []
        if 'ставропольский край' in address:
            components.append('Ставропольский край')
        if 'ставрополь' in address:
            components.append('г Ставрополь')
        # Ищем улицу/проспект
        street_match = re.search(r'(улица|проспект|переулок)\s+([^,]+)', address)
        if street_match:
            street_type = street_match.group(1)
            street_name = street_match.group(2).strip()
            components.append(f"{street_type} {street_name.title()}")
        # Ищем номер дома
        house_match = re.search(r'дом\s+([\w-]+)', address)
        if house_match:
            components.append(f"д {house_match.group(1)}")
        if components:
            return ', '.join(components)
        else:
            return address.title()

    def display_statistics(self, terbank_filter="Все тербанки"):
        """Отображение статистики в таблице"""
        self.current_terbank = terbank_filter
        filtered_stats = {}
        for fio, stats in self.employee_stats.items():
            if terbank_filter == "Все тербанки" or stats['terbank'] == terbank_filter:
                filtered_stats[fio] = stats
        self.stats_table.setRowCount(len(filtered_stats))
        self.stats_table.setSortingEnabled(False)  # Отключаем сортировку во время обновления
        for row, (fio, stats) in enumerate(filtered_stats.items()):
            # ФИО
            self.stats_table.setItem(row, 0, QTableWidgetItem(fio))
            # Тербанк
            self.stats_table.setItem(row, 1, QTableWidgetItem(stats['terbank']))
            # Количество заявок (числовой тип для корректной сортировки)
            count_item = QTableWidgetItem()
            count_item.setData(Qt.DisplayRole, stats['total_requests'])
            self.stats_table.setItem(row, 2, count_item)
            # Период
            self.stats_table.setItem(row, 3, QTableWidgetItem(stats['period']))
            # Количество рабочих дней
            days_item = QTableWidgetItem()
            days_item.setData(Qt.DisplayRole, stats.get('work_days', 0))
            self.stats_table.setItem(row, 4, days_item)
        self.stats_table.setSortingEnabled(True)  # Включаем сортировку обратно
        # Активируем кнопки управления
        self.top20_button.setEnabled(True)
        self.top20_efficiency_button.setEnabled(True)
        self.services_button.setEnabled(True)
        self.suspicious_button.setEnabled(True)
        self.show_all_button.setEnabled(True)
        self.user_type_combo.setEnabled(True)
        self.rpr_combo.setEnabled(True)

    def filter_by_terbank(self, terbank):
        """Фильтрация по тербанку"""
        self.display_statistics(terbank)

    def show_main_screen(self):
        """Показ главного экрана"""
        self.stacked_widget.setCurrentIndex(0)

    def show_employee_details(self, fio):
        """Показ детальной статистики по сотруднику"""
        if fio in self.employee_stats:
            employee_data = {
                'fio': fio,
                'terbank': self.employee_stats[fio]['terbank'],
                'period': self.employee_stats[fio]['period'],
                'total_requests': self.employee_stats[fio]['total_requests'],
                'daily_stats': {},
                'arm_codes': self.employee_stats[fio]['arm_codes'],
                'total_workload_minutes': self.employee_stats[fio]['total_workload_minutes'],
                'requests_data': self.employee_stats[fio]['requests_data']
            }
            # Создаем или обновляем виджет деталей сотрудника
            employee_widget = EmployeeDetailWidget(employee_data, self)
            if self.stacked_widget.indexOf(self.employee_detail_screen) >= 0:
                self.stacked_widget.removeWidget(self.employee_detail_screen)
            self.employee_detail_screen = employee_widget
            self.stacked_widget.addWidget(self.employee_detail_screen)
            self.stacked_widget.setCurrentWidget(self.employee_detail_screen)

    def show_employee_requests(self, fio):
        """Показ всех заявок сотрудника"""
        if fio in self.employee_stats:
            requests_data = self.employee_stats[fio]['requests_data']
            # Создаем или обновляем виджет всех заявок
            requests_widget = EmployeeRequestsWidget(requests_data, fio, self)
            if self.stacked_widget.indexOf(self.employee_requests_screen) >= 0:
                self.stacked_widget.removeWidget(self.employee_requests_screen)
            self.employee_requests_screen = requests_widget
            self.stacked_widget.addWidget(self.employee_requests_screen)
            self.stacked_widget.setCurrentWidget(self.employee_requests_screen)

    def show_all_requests(self, requests_data, title):
        """Показ всех заявок с возможностью экспорта"""
        # Создаем или обновляем виджет всех заявок
        all_requests_widget = AllRequestsWidget(requests_data, title, self)
        if self.stacked_widget.indexOf(self.all_requests_screen) >= 0:
            self.stacked_widget.removeWidget(self.all_requests_screen)
        self.all_requests_screen = all_requests_widget
        self.stacked_widget.addWidget(self.all_requests_screen)
        self.stacked_widget.setCurrentWidget(self.all_requests_screen)

    def show_code_details(self, code, employee):
        """Показ детальной информации по коду ARM"""
        # Находим все заявки сотрудника с этим кодом
        requests_with_code = []
        if employee in self.employee_stats:
            for request in self.employee_stats[employee]['requests_data']:
                if code in request['arm_codes']:
                    requests_with_code.append(request)
        code_data = {
            'code': code,
            'employee': employee,
            'requests': requests_with_code,
            'work_description': self.get_code_description(code)
        }
        # Создаем или обновляем виджет деталей кода
        code_widget = CodeDetailWidget(code_data, self)
        if self.stacked_widget.indexOf(self.code_detail_screen) >= 0:
            self.stacked_widget.removeWidget(self.code_detail_screen)
        self.code_detail_screen = code_widget
        self.stacked_widget.addWidget(self.code_detail_screen)
        self.stacked_widget.setCurrentWidget(self.code_detail_screen)

    # 🔥 ЕДИНСТВЕННОЕ ИСПРАВЛЕНИЕ ВО ВСЕМ ФАЙЛЕ 🔥
    def show_service_code_requests(self, code, service_name):
        """Показ всех заявок по коду услуги"""
        requests_data = []
        clean_input_code = re.sub(r'\D', '', code)  # Оставляем только цифры

        for employee_stats in self.employee_stats.values():
            for request in employee_stats['requests_data']:
                if request.get('service', '') != service_name:
                    continue
                for arm_code in request['arm_codes']:
                    clean_arm_code = re.sub(r'\D', '', arm_code)  # Например, из '#ARM0100000#' → '0100000'
                    if clean_arm_code == clean_input_code:
                        requests_data.append(request)
                        break  # Достаточно одного совпадения на заявку
        title = f"Заявки по коду {code} для услуги {service_name}"
        self.show_all_requests(requests_data, title)

    def show_address_stats(self, address_stats, employee_name):
        """Показ статистики по адресам"""
        # Создаем или обновляем виджет статистики адресов
        address_widget = AddressStatsWidget(address_stats, employee_name, self)
        if self.stacked_widget.indexOf(self.address_stats_screen) >= 0:
            self.stacked_widget.removeWidget(self.address_stats_screen)
        self.address_stats_screen = address_widget
        self.stacked_widget.addWidget(self.address_stats_screen)
        self.stacked_widget.setCurrentWidget(self.address_stats_screen)

    def show_workload_stats(self, workload_stats, employee_name):
        """Показ статистики по трудозатратам"""
        # Создаем или обновляем виджет статистики трудозатрат
        workload_widget = WorkloadStatsWidget(workload_stats, employee_name, self)
        if self.stacked_widget.indexOf(self.workload_stats_screen) >= 0:
            self.stacked_widget.removeWidget(self.workload_stats_screen)
        self.workload_stats_screen = workload_widget
        self.stacked_widget.addWidget(self.workload_stats_screen)
        self.stacked_widget.setCurrentWidget(self.workload_stats_screen)

    def show_service_stats(self):
        """Показ статистики по услугам"""
        if not self.service_stats:
            QMessageBox.information(self, "Информация", "Нет данных для отображения статистики по услугам")
            return
        # Создаем или обновляем виджет статистики услуг с переключателем
        service_widget = ServiceStatsWithToggleWidget(self.service_stats, self.employee_stats, self)
        if self.stacked_widget.indexOf(self.service_stats_screen) >= 0:
            self.stacked_widget.removeWidget(self.service_stats_screen)
        self.service_stats_screen = service_widget
        self.stacked_widget.addWidget(self.service_stats_screen)
        self.stacked_widget.setCurrentWidget(self.service_stats_screen)

    def show_service_details(self, service_name):
        """Показ детальной информации по услуге"""
        if service_name in self.service_stats:
            # Создаем или обновляем виджет деталей услуги
            service_widget = ServiceDetailWidget(self.service_stats[service_name], self)
            if self.stacked_widget.indexOf(self.service_detail_screen) >= 0:
                self.stacked_widget.removeWidget(self.service_detail_screen)
            self.service_detail_screen = service_widget
            self.stacked_widget.addWidget(self.service_detail_screen)
            self.stacked_widget.setCurrentWidget(self.service_detail_screen)

    def show_service_codes(self, service_codes_data, service_name):
        """Показ кодов ARM для услуги"""
        # Создаем или обновляем виджет кодов услуги
        service_codes_widget = ServiceCodesWidget(service_codes_data, service_name, self)
        if self.stacked_widget.indexOf(self.service_codes_screen) >= 0:
            self.stacked_widget.removeWidget(self.service_codes_screen)
        self.service_codes_screen = service_codes_widget
        self.stacked_widget.addWidget(self.service_codes_screen)
        self.stacked_widget.setCurrentWidget(self.service_codes_screen)

    def show_top20(self):
        """Показ ТОП-20 сотрудников по количеству заявок"""
        if not self.employee_stats:
            QMessageBox.information(self, "Информация", "Нет данных для отображения ТОП-20")
            return
        # Сортируем сотрудников по количеству заявок
        top_employees = sorted(
            self.employee_stats.items(),
            key=lambda x: x[1]['total_requests'],
            reverse=True
        )[:20]
        # Создаем или обновляем виджет ТОП-20
        top20_widget = Top20Widget(top_employees, self)
        if self.stacked_widget.indexOf(self.top20_screen) >= 0:
            self.stacked_widget.removeWidget(self.top20_screen)
        self.top20_screen = top20_widget
        self.stacked_widget.addWidget(self.top20_screen)
        self.stacked_widget.setCurrentWidget(self.top20_screen)

    def show_top20_efficiency(self):
        """Показ ТОП-20 сотрудников по эффективности (трудозатраты/день)"""
        if not self.employee_stats:
            QMessageBox.information(self, "Информация", "Нет данных для отображения ТОП-20 по эффективности")
            return
        # Рассчитываем эффективность для каждого сотрудника
        efficiency_data = []
        for fio, stats in self.employee_stats.items():
            if stats.get('work_days', 0) > 0:
                efficiency = stats['total_workload_minutes'] / stats['work_days']
            else:
                efficiency = 0
            efficiency_data.append((fio, {
                'terbank': stats['terbank'],
                'total_minutes': stats['total_workload_minutes'],
                'work_days': stats.get('work_days', 0),
                'efficiency': efficiency
            }))
        # Сортируем по эффективности (убывание)
        efficiency_data.sort(key=lambda x: x[1]['efficiency'], reverse=True)
        top_employees = efficiency_data[:20]
        # Создаем или обновляем виджет ТОП-20 по эффективности
        top20_efficiency_widget = Top20EfficiencyWidget(top_employees, self)
        if self.stacked_widget.indexOf(self.top20_efficiency_screen) >= 0:
            self.stacked_widget.removeWidget(self.top20_efficiency_screen)
        self.top20_efficiency_screen = top20_efficiency_widget
        self.stacked_widget.addWidget(self.top20_efficiency_screen)
        self.stacked_widget.setCurrentWidget(self.top20_efficiency_screen)

    def show_suspicious_activity(self):
        """Показ подозрительной активности"""
        if not self.employee_stats:
            QMessageBox.information(self, "Информация", "Нет данных для анализа подозрительной активности")
            return
        suspicious_data = self.analyze_suspicious_activity()
        if not suspicious_data:
            QMessageBox.information(self, "Информация", "Подозрительная активность не обнаружена")
            return
        # Создаем или обновляем виджет подозрительной активности
        suspicious_widget = SuspiciousActivityWidget(suspicious_data, self)
        if self.stacked_widget.indexOf(self.suspicious_activity_screen) >= 0:
            self.stacked_widget.removeWidget(self.suspicious_activity_screen)
        self.suspicious_activity_screen = suspicious_widget
        self.stacked_widget.addWidget(self.suspicious_activity_screen)
        self.stacked_widget.setCurrentWidget(self.suspicious_activity_screen)

    def show_suspicious_requests(self, case_data):
        """Показ подозрительных заявок для конкретного случая"""
        requests_data = case_data['suspicious_requests']
        case_info = {
            'employee': case_data['employee'],
            'address': case_data['address'],
            'date': case_data['date'],
            'first_visit_time': case_data['first_visit_time'],
            'new_requests_time': case_data['new_requests_time']
        }
        # Создаем или обновляем виджет подозрительных заявок
        requests_widget = SuspiciousRequestsWidget(requests_data, case_info, self)
        if self.stacked_widget.indexOf(self.suspicious_requests_screen) >= 0:
            self.stacked_widget.removeWidget(self.suspicious_requests_screen)
        self.suspicious_requests_screen = requests_widget
        self.stacked_widget.addWidget(self.suspicious_requests_screen)
        self.stacked_widget.setCurrentWidget(self.suspicious_requests_screen)

    def show_previous_screen(self):
        """Показ предыдущего экрана (для AllRequestsWidget)"""
        # Простая реализация - возврат на главный экран
        self.show_main_screen()

    def analyze_suspicious_activity(self):
        """Анализ подозрительной активности"""
        suspicious_cases = {}
        for employee, stats in self.employee_stats.items():
            employee_cases = []
            # Группируем заявки по адресам и датам
            address_date_groups = {}
            for request in stats['requests_data']:
                if not request.get('registration_date') or not request.get('placement'):
                    continue
                # Нормализуем адрес и фильтруем некорректные
                address = self.normalize_address_with_similarity(request['placement'], stats['requests_data'])
                if address == "Адрес не определен":
                    continue
                # Парсим дату регистрации
                reg_date = self.parse_datetime(request['registration_date'])
                if not reg_date:
                    continue
                date_key = reg_date.strftime('%d.%m.%Y')
                if address not in address_date_groups:
                    address_date_groups[address] = {}
                if date_key not in address_date_groups[address]:
                    address_date_groups[address][date_key] = []
                address_date_groups[address][date_key].append({
                    'request_number': request.get('request_number', ''),
                    'registration_date': reg_date,
                    'completion_date': self.parse_datetime(request.get('completion_date', '')),
                    'placement': address,
                    'arm_codes': request.get('arm_codes', []),
                    'user_type': request.get('user_type', ''),
                    'closing_date': request.get('closing_date', '')
                })
            # Анализируем каждую группу адрес-дата
            for address, date_groups in address_date_groups.items():
                for date_key, requests in date_groups.items():
                    if len(requests) < 2:
                        continue
                    # Сортируем по времени регистрации
                    sorted_requests = sorted(requests, key=lambda x: x['registration_date'])
                    # Находим первый визит (самую раннюю заявку с завершением работ)
                    first_visit = None
                    for req in sorted_requests:
                        if req['completion_date']:
                            first_visit = req
                            break
                    if not first_visit:
                        continue
                    # Ищем заявки, созданные после первого визита в течение 40 минут
                    suspicious_requests = []
                    first_visit_time = first_visit['registration_date']
                    for req in sorted_requests:
                        if req['registration_date'] > first_visit_time:
                            time_diff = (req['registration_date'] - first_visit_time).total_seconds() / 60  # в минутах
                            if time_diff <= 40:  # 40 минутный интервал
                                suspicious_requests.append(req)
                    if len(suspicious_requests) >= 2:  # Минимум 2 подозрительные заявки
                        employee_cases.append({
                            'address': address,
                            'date': date_key,
                            'first_visit_time': first_visit_time.strftime('%H:%M'),
                            'new_requests_time': f"{suspicious_requests[0]['registration_date'].strftime('%H:%M')}-{suspicious_requests[-1]['registration_date'].strftime('%H:%M')}",
                            'new_requests_count': len(suspicious_requests),
                            'suspicious_requests': suspicious_requests
                        })
            if employee_cases:
                suspicious_cases[employee] = employee_cases
        return suspicious_cases

    def load_excel_file(self):
        """Загрузка Excel файла"""
        if self.ktr_df is None:
            QMessageBox.warning(self, "Внимание", "Сначала загрузите обязательный файл КТР!")
            return
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Выберите Excel файл для обработки",
            "",
            "Excel Files (*.xlsx *.xls);;All Files (*)"
        )
        if file_path:
            try:
                self.status_label.setText("⏳ Загрузка файла для обработки...")
                self.status_label.setStyleSheet("""
                QLabel {
                    color: #856404;
                    font-size: 11px;
                    padding: 8px;
                    background-color: #FFF3CD;
                    border-radius: 6px;
                    border-left: 4px solid #FFC107;
                }
                """)
                self.df = pd.read_excel(file_path)
                file_name = file_path.split('/')[-1]
                # Обрезаем длинное имя файла
                if len(file_name) > 30:
                    file_name = file_name[:27] + "..."
                self.file_label.setText(f"✅ {file_name}")
                self.file_label.setStyleSheet("""
                QLabel {
                    color: #155724;
                    font-size: 14px;
                    font-weight: bold;
                }
                """)
                self.process_data()
                self.status_label.setText("✅ Оба файла загружены успешно! Данные обработаны.")
                self.status_label.setStyleSheet("""
                QLabel {
                    color: #155724;
                    font-size: 11px;
                    padding: 8px;
                    background-color: #D4EDDA;
                    border-radius: 6px;
                    border-left: 4px solid #28A745;
                }
                """)
            except Exception as e:
                self.status_label.setText("❌ Ошибка при загрузке файла для обработки")
                self.status_label.setStyleSheet("""
                QLabel {
                    color: #721C24;
                    font-size: 11px;
                    padding: 8px;
                    background-color: #F8D7DA;
                    border-radius: 6px;
                    border-left: 4px solid #DC3545;
                }
                """)
                QMessageBox.critical(self, "Ошибка", f"Ошибка при загрузке файла: {str(e)}")

    def on_table_double_click(self, row, column):
        """Обработка двойного клика по таблице"""
        fio = self.stats_table.item(row, 0).text()
        self.show_employee_details(fio)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    # Устанавливаем стиль приложения с стандартными шрифтами
    app.setStyleSheet("""
    QMainWindow {
        background-color: #F0F7FF;
    }
    QWidget {
        font-family: Arial, Helvetica, sans-serif;
    }
    QMessageBox {
        background-color: white;
    }
    QMessageBox QLabel {
        color: #2C3E50;
        font-size: 14px;
    }
    """)
    window = ExcelAnalyzerApp()
    window.show()
    sys.exit(app.exec())
